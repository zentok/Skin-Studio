package com.skinstudio.client;

import java.util.List;

/**
 * Разметка развёртки скина 64×64 и плаща 64×32: части тела, грани, зеркальные пары.
 */
public final class SkinLayout {
	private SkinLayout() {
	}

	public static final int TOP = 0, BOTTOM = 1, RIGHT = 2, FRONT = 3, LEFT = 4, BACK = 5;
	private static final int[] MIRROR_FACE = {TOP, BOTTOM, LEFT, FRONT, RIGHT, BACK};

	/** Коробка модели в развёртке: u,v — левый верхний угол; w,h,d — ширина, высота, глубина. */
	public record Box(String name, int u, int v, int w, int h, int d, boolean outer) {
		/** {x, y, ширина, высота} грани. */
		public int[] face(int f) {
			return switch (f) {
				case TOP -> new int[]{u + d, v, w, d};
				case BOTTOM -> new int[]{u + d + w, v, w, d};
				case RIGHT -> new int[]{u, v + d, d, h};
				case FRONT -> new int[]{u + d, v + d, w, h};
				case LEFT -> new int[]{u + d + w, v + d, d, h};
				default -> new int[]{u + 2 * d + w, v + d, w, h};
			};
		}

		public int[] bounds() {
			return new int[]{u, v, 2 * (w + d), d + h};
		}

		/** Номер грани под пикселем или -1. */
		public int faceAt(int x, int y) {
			for (int f = 0; f < 6; f++) {
				int[] r = face(f);
				if (x >= r[0] && y >= r[1] && x < r[0] + r[2] && y < r[1] + r[3]) return f;
			}
			return -1;
		}
	}

	public static final int HEAD = 0, HAT = 1, BODY = 2, JACKET = 3, R_ARM = 4, L_ARM = 5, R_SLEEVE = 6, L_SLEEVE = 7,
			R_LEG = 8, L_LEG = 9, R_PANTS = 10, L_PANTS = 11;

	/** Для каждой коробки — её зеркальная пара (правая ⇄ левая сторона тела). */
	public static final int[] SKIN_PAIRS = {HEAD, HAT, BODY, JACKET, L_ARM, R_ARM, L_SLEEVE, R_SLEEVE, L_LEG, R_LEG, L_PANTS, R_PANTS};
	public static final int[] CAPE_PAIRS = {0};

	private static final List<Box> CLASSIC = build(4);
	private static final List<Box> SLIM = build(3);
	public static final List<Box> CAPE = List.of(new Box("Плащ", 0, 0, 10, 16, 1, false));

	private static List<Box> build(int aw) {
		return List.of(
				new Box("Голова", 0, 0, 8, 8, 8, false),
				new Box("Голова · внешний слой", 32, 0, 8, 8, 8, true),
				new Box("Торс", 16, 16, 8, 12, 4, false),
				new Box("Куртка · внешний слой", 16, 32, 8, 12, 4, true),
				new Box("Правая рука", 40, 16, aw, 12, 4, false),
				new Box("Левая рука", 32, 48, aw, 12, 4, false),
				new Box("Правый рукав · внешний", 40, 32, aw, 12, 4, true),
				new Box("Левый рукав · внешний", 48, 48, aw, 12, 4, true),
				new Box("Правая нога", 0, 16, 4, 12, 4, false),
				new Box("Левая нога", 16, 48, 4, 12, 4, false),
				new Box("Правая штанина · внешний", 0, 32, 4, 12, 4, true),
				new Box("Левая штанина · внешний", 0, 48, 4, 12, 4, true));
	}

	public static List<Box> skinBoxes(boolean slim) {
		return slim ? SLIM : CLASSIC;
	}

	public static int boxAt(List<Box> boxes, int x, int y) {
		for (int i = 0; i < boxes.size(); i++) if (boxes.get(i).faceAt(x, y) >= 0) return i;
		return -1;
	}

	/** Прямоугольник грани под пикселем или null. */
	public static int[] faceRect(List<Box> boxes, int x, int y) {
		int b = boxAt(boxes, x, y);
		if (b < 0) return null;
		return boxes.get(b).face(boxes.get(b).faceAt(x, y));
	}

	/** Зеркальный пиксель (правая ⇄ левая сторона) или null. */
	public static int[] mirror(List<Box> boxes, int[] pairs, int x, int y) {
		int bi = boxAt(boxes, x, y);
		if (bi < 0) return null;
		Box a = boxes.get(bi);
		int f = a.faceAt(x, y);
		int[] r = a.face(f);
		int lx = x - r[0], ly = y - r[1];
		Box b = boxes.get(pairs[bi]);
		int[] r2 = b.face(MIRROR_FACE[f]);
		int mx = r2[0] + (r2[2] - 1 - lx);
		int my = r2[1] + ly;
		if (mx == x && my == y) return null;
		return new int[]{mx, my};
	}

	/** Перестраивает руки под обычную (4px) или тонкую (3px) ширину. */
	public static void convertArms(PixelImage img, boolean toSlim) {
		List<Box> from = skinBoxes(!toSlim), to = skinBoxes(toSlim);
		PixelImage src = img.copy();
		int[] arms = {R_ARM, L_ARM, R_SLEEVE, L_SLEEVE};
		for (int ai : arms) {
			Box a = from.get(ai), b = to.get(ai);
			img.fill(a.u(), a.v(), 16, 16, 0);
			for (int f = 0; f < 6; f++) {
				int[] rs = a.face(f), rd = b.face(f);
				for (int y = 0; y < rd[3]; y++)
					for (int x = 0; x < rd[2]; x++) {
						int sx = rs[0] + x * rs[2] / rd[2];
						int sy = rs[1] + y * rs[3] / rd[3];
						img.set(rd[0] + x, rd[1] + y, src.get(sx, sy));
					}
			}
		}
	}

	/** Тонкие руки определяются по пустому пикселю (54, 20), как в ванильной игре. */
	public static boolean detectSlim(PixelImage img) {
		return img.w == 64 && img.h == 64 && ((img.get(54, 20) >>> 24) == 0);
	}

	/** Приводит любую картинку скина к 64×64. */
	public static PixelImage normalizeSkin(PixelImage img) {
		if (img.w == 64 && img.h == 64) return img;
		if (img.w == 64 && img.h == 32) {
			PixelImage out = new PixelImage(64, 64);
			for (int y = 0; y < 32; y++) for (int x = 0; x < 64; x++) out.set(x, y, img.get(x, y));
			for (int y = 0; y < 16; y++)
				for (int x = 0; x < 16; x++) {
					out.set(16 + x, 48 + y, img.get(x, 16 + y));
					out.set(32 + x, 48 + y, img.get(40 + x, 16 + y));
				}
			return out;
		}
		if (img.w == 2 * img.h) return normalizeSkin(img.resized(64, 32));
		return img.resized(64, 64);
	}

	public static PixelImage normalizeCape(PixelImage img) {
		if (img.w == 64 && img.h == 32) return img;
		if (img.w == 22 && img.h == 17) {
			PixelImage out = new PixelImage(64, 32);
			for (int y = 0; y < 17; y++) for (int x = 0; x < 22; x++) out.set(x, y, img.get(x, y));
			return out;
		}
		return img.resized(64, 32);
	}

	private static void fillBox(PixelImage img, Box b, int c) {
		for (int f = 0; f < 6; f++) {
			int[] r = b.face(f);
			img.fill(r[0], r[1], r[2], r[3], c);
		}
	}

	private static void sideRows(PixelImage img, Box b, int fromRow, int rows, int c) {
		for (int f : new int[]{RIGHT, FRONT, LEFT, BACK}) {
			int[] r = b.face(f);
			img.fill(r[0], r[1] + fromRow, r[2], rows, c);
		}
	}

	/** Заготовка нового скина. */
	public static PixelImage defaultSkin(boolean slim) {
		PixelImage img = new PixelImage(64, 64);
		List<Box> b = skinBoxes(slim);
		int skin = 0xFFC99A72, hair = 0xFF4A2F1F, shirt = 0xFF2FA89A, pants = 0xFF3A4A8F, shoes = 0xFF4D4D4D, belt = 0xFF6B4A2F;
		Box head = b.get(HEAD);
		fillBox(img, head, skin);
		int[] top = head.face(TOP);
		img.fill(top[0], top[1], top[2], top[3], hair);
		int[] fr = head.face(FRONT), rs = head.face(RIGHT), ls = head.face(LEFT), bk = head.face(BACK);
		img.fill(fr[0], fr[1], 8, 2, hair);
		img.fill(rs[0], rs[1], 8, 3, hair);
		img.fill(ls[0], ls[1], 8, 3, hair);
		img.fill(bk[0], bk[1], 8, 6, hair);
		img.set(fr[0] + 1, fr[1] + 4, 0xFFFFFFFF);
		img.set(fr[0] + 2, fr[1] + 4, 0xFF3B6BD6);
		img.set(fr[0] + 5, fr[1] + 4, 0xFF3B6BD6);
		img.set(fr[0] + 6, fr[1] + 4, 0xFFFFFFFF);
		img.fill(fr[0] + 3, fr[1] + 6, 2, 1, 0xFF8A4A3A);

		Box body = b.get(BODY);
		fillBox(img, body, shirt);
		sideRows(img, body, 10, 2, belt);

		for (int ai : new int[]{R_ARM, L_ARM}) {
			Box arm = b.get(ai);
			fillBox(img, arm, skin);
			sideRows(img, arm, 0, 4, shirt);
			int[] t = arm.face(TOP);
			img.fill(t[0], t[1], t[2], t[3], shirt);
		}
		for (int li : new int[]{R_LEG, L_LEG}) {
			Box leg = b.get(li);
			fillBox(img, leg, pants);
			sideRows(img, leg, 10, 2, shoes);
			int[] bt = leg.face(BOTTOM);
			img.fill(bt[0], bt[1], bt[2], bt[3], shoes);
		}
		return img;
	}

	/** Заготовка нового плаща. */
	public static PixelImage defaultCape() {
		PixelImage img = new PixelImage(64, 32);
		Box c = CAPE.get(0);
		fillBox(img, c, 0xFF6B2A8A);
		for (int f : new int[]{FRONT, BACK}) {
			int[] r = c.face(f);
			for (int y = 0; y < r[3]; y++)
				for (int x = 0; x < r[2]; x++)
					if (x == 0 || y == 0 || x == r[2] - 1 || y == r[3] - 1) img.set(r[0] + x, r[1] + y, 0xFFF2C233);
			int cx = r[0] + r[2] / 2, cy = r[1] + 6;
			img.fill(cx - 1, cy - 2, 2, 5, 0xFFF2C233);
			img.fill(cx - 3, cy, 6, 1, 0xFFF2C233);
		}
		return img;
	}

	/** Шахматка для прозрачных мест. */
	public static PixelImage checker(int w, int h) {
		PixelImage img = new PixelImage(w, h);
		for (int y = 0; y < h; y++)
			for (int x = 0; x < w; x++) img.p[y * w + x] = ((x + y) & 1) == 0 ? 0xFF2B2E34 : 0xFF363940;
		return img;
	}
}
