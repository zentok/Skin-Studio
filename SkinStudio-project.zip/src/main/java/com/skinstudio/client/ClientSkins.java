package com.skinstudio.client;

import com.skinstudio.SkinNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Скины и плащи из Skin Studio для игроков в мире: свой — сразу из библиотеки,
 * чужие — с сервера (у кого тоже стоит мод).
 */
public final class ClientSkins {
	public static final class Entry {
		private final String key;
		private DynTex skin;
		private DynTex cape;
		public boolean slim;

		Entry(String key) {
			this.key = key;
		}

		public boolean hasSkin() {
			return skin != null && skin.ready();
		}

		public boolean hasCape() {
			return cape != null && cape.ready();
		}

		public Identifier skinId() {
			return skin.id;
		}

		public Identifier capeId() {
			return cape.id;
		}

		void setSkin(boolean slim, PixelImage img) {
			if (skin == null) skin = new DynTex("players/" + key + "/skin");
			skin.update(img);
			this.slim = slim;
		}

		void setCape(@Nullable PixelImage img) {
			if (img == null) {
				if (cape != null) cape.destroy();
				cape = null;
				return;
			}
			if (cape == null) cape = new DynTex("players/" + key + "/cape");
			cape.update(img);
		}

		void destroy() {
			if (skin != null) skin.destroy();
			if (cape != null) cape.destroy();
			skin = null;
			cape = null;
		}
	}

	private static final Map<UUID, Entry> MAP = new HashMap<>();
	private static boolean localDirty = true;
	private static boolean uploadPending = false;
	private static int uploadTries = 0;
	private static PixelImage pendingSkin, pendingCape;
	private static boolean pendingSlim;

	private ClientSkins() {
	}

	@Nullable
	public static Entry get(UUID id) {
		return MAP.get(id);
	}

	private static Entry entry(UUID id) {
		return MAP.computeIfAbsent(id, u -> new Entry(u.toString().toLowerCase(java.util.Locale.ROOT)));
	}

	public static void markLocalDirty() {
		localDirty = true;
	}

	public static void setSkin(UUID id, boolean slim, int[] pixels) {
		entry(id).setSkin(slim, new PixelImage(64, 64, pixels));
	}

	public static void setCape(UUID id, @Nullable int[] pixels) {
		Entry e = MAP.get(id);
		if (pixels == null) {
			if (e != null) e.setCape(null);
			return;
		}
		entry(id).setCape(new PixelImage(64, 32, pixels));
	}

	public static void clear(UUID id) {
		Entry e = MAP.remove(id);
		if (e != null) e.destroy();
	}

	public static void clearAll() {
		for (Entry e : MAP.values()) e.destroy();
		MAP.clear();
		localDirty = true;
		uploadPending = false;
	}

	/** Каждый тик: надеть свой скин локально и отправить его на сервер, когда сервер готов принять. */
	public static void tick(MinecraftClient mc) {
		if (mc.player == null) return;
		if (localDirty) {
			localDirty = false;
			SkinLibrary lib = SkinLibrary.get();
			SkinLibrary.SkinEntry e = lib.activeEntry();
			pendingSkin = lib.loadSkin(e.name);
			pendingSlim = e.slim;
			pendingCape = lib.activeCape.isEmpty() ? null : lib.loadCape(lib.activeCape);
			Entry own = entry(mc.player.getUuid());
			own.setSkin(pendingSlim, pendingSkin);
			own.setCape(pendingCape);
			uploadPending = true;
			uploadTries = 0;
		}
		if (uploadPending) {
			if (ClientPlayNetworking.canSend(SkinNetworking.SKIN_UPLOAD)) {
				upload();
				uploadPending = false;
			} else if (++uploadTries > 400) {
				uploadPending = false; // на сервере нет мода — скин виден только тебе
			}
		}
	}

	private static void upload() {
		PacketByteBuf buf = PacketByteBufs.create();
		buf.writeBoolean(pendingSlim);
		for (int c : pendingSkin.p) buf.writeInt(c);
		ClientPlayNetworking.send(SkinNetworking.SKIN_UPLOAD, buf);

		PacketByteBuf cape = PacketByteBufs.create();
		cape.writeBoolean(pendingCape != null);
		if (pendingCape != null) for (int c : pendingCape.p) cape.writeInt(c);
		ClientPlayNetworking.send(SkinNetworking.CAPE_UPLOAD, cape);
	}
}
