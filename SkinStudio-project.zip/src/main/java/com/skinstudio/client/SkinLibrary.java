package com.skinstudio.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.skinstudio.HeightHolder;
import com.skinstudio.SkinStudio;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * Библиотека скинов и плащей в .minecraft/SkinStudio.
 * Выбранный скин записывается поверх файла CustomSkinLoader с ником игрока — всегда один и тот же файл.
 */
public final class SkinLibrary {
	private static SkinLibrary instance;
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS");
	private static final int MAX_BACKUPS = 15;

	public static final class SkinEntry {
		public String name;
		public boolean slim;
		public float height = HeightHolder.DEFAULT;

		SkinEntry(String name) {
			this.name = name;
		}
	}

	public final Path gameDir;
	public final Path root;
	public final Path skinsDir;
	public final Path capesDir;
	public final Path stickersDir;
	public final Path photosDir;
	public final Path backupsDir;
	private final Path stateFile;

	public final List<SkinEntry> skins = new ArrayList<>();
	public final List<String> capes = new ArrayList<>();
	public String active = "";
	/** Пусто — без плаща из Skin Studio. */
	public String activeCape = "";
	public boolean dollLeft = false;

	private final DynTex activeSkinTex = new DynTex("preview/active_skin");
	private final DynTex activeCapeTex = new DynTex("preview/active_cape");
	private final DynTex browseSkinTex = new DynTex("preview/browse_skin");
	private final DynTex browseCapeTex = new DynTex("preview/browse_cape");
	private boolean skinTexDirty = true, capeTexDirty = true;
	private String browseSkinName = null, browseCapeName = null;

	public static SkinLibrary get() {
		if (instance == null) {
			instance = new SkinLibrary();
			instance.load();
		}
		return instance;
	}

	private SkinLibrary() {
		gameDir = FabricLoader.getInstance().getGameDir();
		root = gameDir.resolve("SkinStudio");
		skinsDir = root.resolve("skins");
		capesDir = root.resolve("capes");
		stickersDir = root.resolve("stickers");
		photosDir = root.resolve("photos");
		backupsDir = root.resolve("backups");
		stateFile = root.resolve("state.json");
	}

	// ---------------------------------------------------------------- загрузка

	private void load() {
		try {
			for (Path p : new Path[]{skinsDir, capesDir, stickersDir, photosDir, backupsDir}) Files.createDirectories(p);
		} catch (IOException e) {
			SkinStudio.LOGGER.error("Не удалось создать папки SkinStudio", e);
		}
		skins.clear();
		for (String n : listPngNames(skinsDir)) {
			SkinEntry e = new SkinEntry(n);
			readMeta(e);
			skins.add(e);
		}
		capes.clear();
		capes.addAll(listPngNames(capesDir));
		readState();
		if (skins.isEmpty()) importInitial();
		if (find(active) == null) active = skins.get(0).name;
		if (!activeCape.isEmpty() && !capes.contains(activeCape)) activeCape = "";
		saveState();
	}

	private static List<String> listPngNames(Path dir) {
		List<String> out = new ArrayList<>();
		if (!Files.isDirectory(dir)) return out;
		try (Stream<Path> s = Files.list(dir)) {
			s.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
					.sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT)))
					.forEach(p -> {
						String f = p.getFileName().toString();
						out.add(f.substring(0, f.length() - 4));
					});
		} catch (IOException e) {
			SkinStudio.LOGGER.error("Не удалось прочитать " + dir, e);
		}
		return out;
	}

	/** Первый запуск: берём скин (и плащ) из папки CustomSkinLoader, если он там есть. */
	private void importInitial() {
		Path csl = findCsl("skins");
		PixelImage img = null;
		if (Files.isRegularFile(csl)) {
			try {
				img = SkinLayout.normalizeSkin(PixelImage.read(csl));
			} catch (IOException e) {
				SkinStudio.LOGGER.warn("Не удалось прочитать скин CustomSkinLoader " + csl, e);
			}
		}
		if (img != null) createSkin("Мой скин", img, SkinLayout.detectSlim(img), HeightHolder.DEFAULT);
		else createSkin("Обычный", SkinLayout.defaultSkin(false), false, HeightHolder.DEFAULT);
		active = skins.get(0).name;

		Path cslCape = findCsl("capes");
		if (capes.isEmpty() && Files.isRegularFile(cslCape)) {
			try {
				activeCape = createCape("Мой плащ", SkinLayout.normalizeCape(PixelImage.read(cslCape)));
			} catch (IOException e) {
				SkinStudio.LOGGER.warn("Не удалось прочитать плащ CustomSkinLoader " + cslCape, e);
			}
		}
	}

	private void readMeta(SkinEntry e) {
		Path meta = skinsDir.resolve(e.name + ".json");
		if (Files.isRegularFile(meta)) {
			try (Reader r = Files.newBufferedReader(meta, StandardCharsets.UTF_8)) {
				JsonObject o = GSON.fromJson(r, JsonObject.class);
				if (o != null) {
					if (o.has("slim")) e.slim = o.get("slim").getAsBoolean();
					if (o.has("height")) e.height = HeightHolder.clamp(o.get("height").getAsFloat());
				}
				return;
			} catch (Exception ex) {
				SkinStudio.LOGGER.warn("Повреждён файл " + meta, ex);
			}
		}
		try {
			e.slim = SkinLayout.detectSlim(SkinLayout.normalizeSkin(PixelImage.read(skinsDir.resolve(e.name + ".png"))));
		} catch (IOException ignored) {
		}
	}

	public void saveMeta(SkinEntry e) {
		JsonObject o = new JsonObject();
		o.addProperty("slim", e.slim);
		o.addProperty("height", e.height);
		writeJson(skinsDir.resolve(e.name + ".json"), o);
	}

	private void readState() {
		if (!Files.isRegularFile(stateFile)) return;
		try (Reader r = Files.newBufferedReader(stateFile, StandardCharsets.UTF_8)) {
			JsonObject o = GSON.fromJson(r, JsonObject.class);
			if (o == null) return;
			if (o.has("active")) active = o.get("active").getAsString();
			if (o.has("activeCape")) activeCape = o.get("activeCape").getAsString();
			if (o.has("dollLeft")) dollLeft = o.get("dollLeft").getAsBoolean();
		} catch (Exception e) {
			SkinStudio.LOGGER.warn("Повреждён state.json", e);
		}
	}

	public void saveState() {
		JsonObject o = new JsonObject();
		o.addProperty("active", active);
		o.addProperty("activeCape", activeCape);
		o.addProperty("dollLeft", dollLeft);
		writeJson(stateFile, o);
	}

	private static void writeJson(Path path, JsonObject o) {
		try {
			Files.createDirectories(path.getParent());
			try (Writer w = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
				GSON.toJson(o, w);
			}
		} catch (IOException e) {
			SkinStudio.LOGGER.error("Не удалось записать " + path, e);
		}
	}

	// ---------------------------------------------------------------- имена

	public static String sanitize(String raw) {
		StringBuilder sb = new StringBuilder();
		for (char c : (raw == null ? "" : raw).toCharArray()) {
			if (c < 32 || "<>:\"/\\|?*".indexOf(c) >= 0) continue;
			sb.append(c);
		}
		String s = sb.toString().trim();
		while (s.endsWith(".")) s = s.substring(0, s.length() - 1).trim();
		if (s.length() > 32) s = s.substring(0, 32).trim();
		return s.isEmpty() ? "Скин" : s;
	}

	public String uniqueSkinName(String base) {
		String b = sanitize(base);
		if (find(b) == null) return b;
		for (int i = 2; ; i++) if (find(b + " " + i) == null) return b + " " + i;
	}

	public String uniqueCapeName(String base) {
		String b = sanitize(base);
		if (!containsIgnoreCase(capes, b)) return b;
		for (int i = 2; ; i++) if (!containsIgnoreCase(capes, b + " " + i)) return b + " " + i;
	}

	private static boolean containsIgnoreCase(List<String> list, String s) {
		for (String x : list) if (x.equalsIgnoreCase(s)) return true;
		return false;
	}

	public String username() {
		return MinecraftClient.getInstance().getSession().getUsername();
	}

	// ---------------------------------------------------------------- скины

	@Nullable
	public SkinEntry find(String name) {
		if (name == null) return null;
		for (SkinEntry e : skins) if (e.name.equalsIgnoreCase(name)) return e;
		return null;
	}

	public SkinEntry activeEntry() {
		SkinEntry e = find(active);
		if (e == null) {
			if (skins.isEmpty()) createSkin("Обычный", SkinLayout.defaultSkin(false), false, HeightHolder.DEFAULT);
			e = skins.get(0);
			active = e.name;
		}
		return e;
	}

	public int indexOf(String name) {
		for (int i = 0; i < skins.size(); i++) if (skins.get(i).name.equalsIgnoreCase(name)) return i;
		return -1;
	}

	public PixelImage loadSkin(String name) {
		try {
			return SkinLayout.normalizeSkin(PixelImage.read(skinsDir.resolve(name + ".png")));
		} catch (IOException e) {
			SkinEntry en = find(name);
			return SkinLayout.defaultSkin(en != null && en.slim);
		}
	}

	public void saveSkin(SkinEntry e, PixelImage img) {
		try {
			img.write(skinsDir.resolve(e.name + ".png"));
		} catch (IOException ex) {
			SkinStudio.LOGGER.error("Не удалось сохранить скин " + e.name, ex);
		}
		saveMeta(e);
		if (e.name.equalsIgnoreCase(active)) skinTexDirty = true;
		if (e.name.equalsIgnoreCase(browseSkinName)) browseSkinName = null;
	}

	public SkinEntry createSkin(String name, PixelImage img, boolean slim, float height) {
		SkinEntry e = new SkinEntry(uniqueSkinName(name));
		e.slim = slim;
		e.height = HeightHolder.clamp(height);
		skins.add(e);
		saveSkin(e, img);
		return e;
	}

	public void renameSkin(SkinEntry e, String newName) {
		String n = sanitize(newName);
		if (n.equals(e.name) || (find(n) != null && find(n) != e)) return;
		try {
			Path oldPng = skinsDir.resolve(e.name + ".png"), oldJson = skinsDir.resolve(e.name + ".json");
			Files.move(oldPng, skinsDir.resolve(n + ".png"), StandardCopyOption.REPLACE_EXISTING);
			if (Files.exists(oldJson)) Files.move(oldJson, skinsDir.resolve(n + ".json"), StandardCopyOption.REPLACE_EXISTING);
			if (e.name.equalsIgnoreCase(active)) active = n;
			e.name = n;
			browseSkinName = null;
			saveState();
		} catch (IOException ex) {
			SkinStudio.LOGGER.error("Не удалось переименовать скин", ex);
		}
	}

	/** Файл не удаляется насовсем, а переезжает в backups/deleted. */
	public void deleteSkin(String name) {
		SkinEntry e = find(name);
		if (e == null) return;
		moveToDeleted(skinsDir.resolve(e.name + ".png"));
		moveToDeleted(skinsDir.resolve(e.name + ".json"));
		skins.remove(e);
		browseSkinName = null;
		if (skins.isEmpty()) createSkin("Обычный", SkinLayout.defaultSkin(false), false, HeightHolder.DEFAULT);
		if (find(active) == null) {
			active = skins.get(0).name;
			saveState();
			applySkin();
		}
	}

	/** Листание стрелками под куклой: выбранный скин сразу надевается. */
	public void cycle(int dir) {
		if (skins.isEmpty()) return;
		int i = indexOf(active);
		int n = Math.floorMod(i + dir, skins.size());
		setActive(skins.get(n).name);
	}

	public void setActive(String name) {
		SkinEntry e = find(name);
		if (e == null) return;
		active = e.name;
		saveState();
		applySkin();
	}

	/** Записывает выбранный скин поверх файла CustomSkinLoader (то же имя, новый файл не создаётся). */
	public void applySkin() {
		SkinEntry e = activeEntry();
		writeCsl("skins", loadSkin(e.name));
		skinTexDirty = true;
		ClientSkins.markLocalDirty();
	}

	// ---------------------------------------------------------------- плащи

	public PixelImage loadCape(String name) {
		try {
			return SkinLayout.normalizeCape(PixelImage.read(capesDir.resolve(name + ".png")));
		} catch (IOException e) {
			return SkinLayout.defaultCape();
		}
	}

	public void saveCape(String name, PixelImage img) {
		try {
			img.write(capesDir.resolve(name + ".png"));
		} catch (IOException ex) {
			SkinStudio.LOGGER.error("Не удалось сохранить плащ " + name, ex);
		}
		if (name.equalsIgnoreCase(activeCape)) capeTexDirty = true;
		if (name.equalsIgnoreCase(browseCapeName)) browseCapeName = null;
	}

	public String createCape(String name, PixelImage img) {
		String n = uniqueCapeName(name);
		capes.add(n);
		saveCape(n, img);
		return n;
	}

	public String renameCape(String oldName, String newName) {
		String n = sanitize(newName);
		if (n.equals(oldName) || containsIgnoreCase(capes, n)) return oldName;
		try {
			Files.move(capesDir.resolve(oldName + ".png"), capesDir.resolve(n + ".png"), StandardCopyOption.REPLACE_EXISTING);
			capes.set(capes.indexOf(oldName), n);
			if (oldName.equalsIgnoreCase(activeCape)) activeCape = n;
			browseCapeName = null;
			saveState();
			return n;
		} catch (IOException | IndexOutOfBoundsException ex) {
			SkinStudio.LOGGER.error("Не удалось переименовать плащ", ex);
			return oldName;
		}
	}

	public void deleteCape(String name) {
		if (!capes.remove(name)) return;
		moveToDeleted(capesDir.resolve(name + ".png"));
		browseCapeName = null;
		if (name.equalsIgnoreCase(activeCape)) setActiveCape("");
	}

	public void setActiveCape(String name) {
		activeCape = (name == null || !capes.contains(name)) ? "" : name;
		saveState();
		applyCape();
	}

	public void applyCape() {
		if (activeCape.isEmpty()) {
			Path f = findCsl("capes");
			if (Files.isRegularFile(f)) {
				backup("capes", f);
				try {
					Files.deleteIfExists(f);
				} catch (IOException e) {
					SkinStudio.LOGGER.error("Не удалось снять плащ CustomSkinLoader", e);
				}
			}
		} else {
			writeCsl("capes", loadCape(activeCape));
		}
		capeTexDirty = true;
		ClientSkins.markLocalDirty();
	}

	// ---------------------------------------------------------------- CustomSkinLoader

	/** Файл &lt;ник&gt;.png в CustomSkinLoader/LocalSkin/&lt;sub&gt;; если он уже есть с другим регистром букв — берём его. */
	public Path findCsl(String sub) {
		Path dir = gameDir.resolve("CustomSkinLoader").resolve("LocalSkin").resolve(sub);
		String file = username() + ".png";
		if (Files.isDirectory(dir)) {
			try (Stream<Path> s = Files.list(dir)) {
				Path match = s.filter(p -> p.getFileName().toString().equalsIgnoreCase(file)).findFirst().orElse(null);
				if (match != null) return match;
			} catch (IOException ignored) {
			}
		}
		return dir.resolve(file);
	}

	private void writeCsl(String sub, PixelImage img) {
		Path target = findCsl(sub);
		try {
			Files.createDirectories(target.getParent());
			if (Files.isRegularFile(target)) backup(sub, target);
			img.write(target);
		} catch (IOException e) {
			SkinStudio.LOGGER.error("Не удалось записать " + target, e);
		}
	}

	private void backup(String sub, Path file) {
		try {
			Files.createDirectories(backupsDir);
			Files.copy(file, backupsDir.resolve(sub + "_" + LocalDateTime.now().format(STAMP) + ".png"), StandardCopyOption.REPLACE_EXISTING);
			List<Path> old = new ArrayList<>();
			try (Stream<Path> s = Files.list(backupsDir)) {
				s.filter(p -> Files.isRegularFile(p) && p.getFileName().toString().startsWith(sub + "_")).sorted().forEach(old::add);
			}
			for (int i = 0; i < old.size() - MAX_BACKUPS; i++) Files.deleteIfExists(old.get(i));
		} catch (IOException e) {
			SkinStudio.LOGGER.warn("Не удалось сделать резервную копию", e);
		}
	}

	private void moveToDeleted(Path file) {
		if (!Files.exists(file)) return;
		try {
			Path dir = backupsDir.resolve("deleted");
			Files.createDirectories(dir);
			String f = file.getFileName().toString();
			Files.move(file, dir.resolve(LocalDateTime.now().format(STAMP) + "_" + f), StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e) {
			SkinStudio.LOGGER.error("Не удалось переместить " + file, e);
		}
	}

	// ---------------------------------------------------------------- текстуры для превью

	public Identifier activeSkinTexture() {
		if (skinTexDirty || !activeSkinTex.ready()) {
			activeSkinTex.update(loadSkin(activeEntry().name));
			skinTexDirty = false;
		}
		return activeSkinTex.id;
	}

	@Nullable
	public Identifier activeCapeTexture() {
		if (activeCape.isEmpty()) return null;
		if (capeTexDirty || !activeCapeTex.ready()) {
			activeCapeTex.update(loadCape(activeCape));
			capeTexDirty = false;
		}
		return activeCapeTex.id;
	}

	public Identifier skinTextureFor(String name) {
		if (!name.equals(browseSkinName) || !browseSkinTex.ready()) {
			browseSkinTex.update(loadSkin(name));
			browseSkinName = name;
		}
		return browseSkinTex.id;
	}

	@Nullable
	public Identifier capeTextureFor(String name) {
		if (name == null || name.isEmpty()) return null;
		if (!name.equals(browseCapeName) || !browseCapeTex.ready()) {
			browseCapeTex.update(loadCape(name));
			browseCapeName = name;
		}
		return browseCapeTex.id;
	}
}
