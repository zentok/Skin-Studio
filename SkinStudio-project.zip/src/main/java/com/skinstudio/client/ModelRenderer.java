package com.skinstudio.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.jetbrains.annotations.Nullable;

/**
 * Рисует модель игрока в интерфейсе без мира (главное меню, редактор, фото, зеркало).
 * Части тела строятся из собственной копии геометрии, а не из PlayerEntityModel:
 * так моды вроде 3D Skin Layers не прячут внешний слой у этой модели.
 */
public final class ModelRenderer {
	public enum Pose {
		STAND("стоит"), WALK("идёт"), WAVE("машет"), SIT("сидит");
		public final String title;

		Pose(String title) {
			this.title = title;
		}
	}

	/** Свой набор частей тела. */
	private static final class Parts {
		final ModelPart head, hat, body, jacket, rightArm, leftArm, rightSleeve, leftSleeve,
				rightLeg, leftLeg, rightPants, leftPants, cloak;

		Parts(boolean slim) {
			ModelPart root = TexturedModelData.of(PlayerEntityModel.getTexturedModelData(Dilation.NONE, slim), 64, 64).createModel();
			head = root.getChild("head");
			hat = root.getChild("hat");
			body = root.getChild("body");
			jacket = root.getChild("jacket");
			rightArm = root.getChild("right_arm");
			leftArm = root.getChild("left_arm");
			rightSleeve = root.getChild("right_sleeve");
			leftSleeve = root.getChild("left_sleeve");
			rightLeg = root.getChild("right_leg");
			leftLeg = root.getChild("left_leg");
			rightPants = root.getChild("right_pants");
			leftPants = root.getChild("left_pants");
			// у плаща в ванильной геометрии уже заложен масштаб под текстуру 64×32
			cloak = root.getChild("cloak");
		}

		ModelPart[] inner() {
			return new ModelPart[]{head, body, rightArm, leftArm, rightLeg, leftLeg};
		}

		ModelPart[] outer() {
			return new ModelPart[]{hat, jacket, rightSleeve, leftSleeve, rightPants, leftPants};
		}
	}

	private static Parts classic;
	private static Parts slim;
	private static final int LIGHT = 15728880;
	private static final float DEG = (float) (Math.PI / 180.0);

	private ModelRenderer() {
	}

	private static Parts parts(boolean thin) {
		if (thin) {
			if (slim == null) slim = new Parts(true);
			return slim;
		}
		if (classic == null) classic = new Parts(false);
		return classic;
	}

	private static void reset(ModelPart p) {
		p.resetTransform();
		p.pitch = 0f;
		p.yaw = 0f;
		p.roll = 0f;
		p.visible = true;
		p.hidden = false;
	}

	/**
	 * @param x        центр по горизонтали
	 * @param feetY    где стоят ноги
	 * @param pxHeight рост модели в пикселях интерфейса
	 * @param bodyYaw  поворот всего тела (0 — лицом к нам)
	 * @param headYaw  поворот головы относительно тела, градусы
	 */
	public static final int ALL_PARTS = 0xFFF;

	public static void draw(DrawContext ctx, int x, int feetY, int pxHeight, float bodyYaw, float bodyPitch,
							float headYaw, float headPitch, Identifier skin, boolean thin, @Nullable Identifier cape,
							boolean outer, Pose pose, float time) {
		draw(ctx, x, feetY, pxHeight, bodyYaw, bodyPitch, headYaw, headPitch, skin, thin, cape, outer, pose, time, ALL_PARTS);
	}

	/**
	 * @param mask биты 0..5 — голова, торс, пр. рука, лв. рука, пр. нога, лв. нога;
	 *             биты 6..11 — внешний слой тех же частей
	 */
	public static void draw(DrawContext ctx, int x, int feetY, int pxHeight, float bodyYaw, float bodyPitch,
							float headYaw, float headPitch, Identifier skin, boolean thin, @Nullable Identifier cape,
							boolean outer, Pose pose, float time, int mask) {
		Parts m = parts(thin);
		for (ModelPart p : m.inner()) reset(p);
		for (ModelPart p : m.outer()) reset(p);
		reset(m.cloak);

		m.head.yaw = headYaw * DEG;
		m.head.pitch = headPitch * DEG;
		float breathe = (float) Math.sin(time * 0.067f) * 0.03f;
		m.rightArm.roll = 0.06f + breathe;
		m.leftArm.roll = -0.06f - breathe;
		switch (pose) {
			case WALK -> {
				float s = (float) Math.cos(time * 0.3f);
				m.rightLeg.pitch = s * 0.8f;
				m.leftLeg.pitch = -s * 0.8f;
				m.rightArm.pitch = -s * 0.6f;
				m.leftArm.pitch = s * 0.6f;
			}
			case WAVE -> {
				m.rightArm.pitch = -2.7f;
				m.rightArm.roll = (float) Math.sin(time * 0.4f) * 0.35f;
			}
			case SIT -> {
				m.rightLeg.pitch = -1.41f;
				m.leftLeg.pitch = -1.41f;
				m.rightLeg.yaw = 0.31f;
				m.leftLeg.yaw = -0.31f;
				m.rightArm.pitch = -0.63f;
				m.leftArm.pitch = -0.63f;
			}
			default -> {
			}
		}
		m.hat.copyTransform(m.head);
		m.jacket.copyTransform(m.body);
		m.rightSleeve.copyTransform(m.rightArm);
		m.leftSleeve.copyTransform(m.leftArm);
		m.rightPants.copyTransform(m.rightLeg);
		m.leftPants.copyTransform(m.leftLeg);

		float size = pxHeight / 2f;
		MatrixStack ms = ctx.getMatrices();
		ms.push();
		ms.translate(x, feetY, 150f);
		ms.scale(size, size, -size);
		ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180f));
		ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(bodyPitch));
		ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(bodyYaw));
		ms.scale(-1f, -1f, 1f);
		ms.translate(0f, -1.501f, 0f);
		if (pose == Pose.SIT) ms.translate(0f, 0.62f, 0f);

		DiffuseLighting.disableGuiDepthLighting();
		VertexConsumerProvider.Immediate imm = ctx.getVertexConsumers();
		VertexConsumer vc = imm.getBuffer(RenderLayer.getEntityTranslucent(skin));
		ModelPart[] in = m.inner(), out = m.outer();
		for (int i = 0; i < in.length; i++) {
			if ((mask & (1 << i)) != 0) in[i].render(ms, vc, LIGHT, OverlayTexture.DEFAULT_UV, 1f, 1f, 1f, 1f);
		}
		if (outer) {
			for (int i = 0; i < out.length; i++) {
				if ((mask & (1 << (6 + i))) != 0) out[i].render(ms, vc, LIGHT, OverlayTexture.DEFAULT_UV, 1f, 1f, 1f, 1f);
			}
		}
		if (cape != null) {
			ms.push();
			ms.translate(0f, 0f, 0.125f);
			float swing = pose == Pose.WALK ? 20f + (float) Math.sin(time * 0.3f) * 6f : 6f;
			ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(swing));
			ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f));
			m.cloak.render(ms, imm.getBuffer(RenderLayer.getEntitySolid(cape)), LIGHT, OverlayTexture.DEFAULT_UV);
			ms.pop();
		}
		ctx.draw();
		ms.pop();
		DiffuseLighting.enableGuiDepthLighting();
	}
}
