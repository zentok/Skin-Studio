package com.skinstudio.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.jetbrains.annotations.Nullable;

/** Рисует модель игрока в интерфейсе без мира (главное меню, редактор, фото). */
public final class ModelRenderer {
	public enum Pose {
		STAND("стоит"), WALK("идёт"), WAVE("машет"), SIT("сидит");
		public final String title;

		Pose(String title) {
			this.title = title;
		}
	}

	private static PlayerEntityModel<LivingEntity> classic;
	private static PlayerEntityModel<LivingEntity> slim;
	private static final int LIGHT = 15728880;
	private static final float DEG = (float) (Math.PI / 180.0);

	private ModelRenderer() {
	}

	private static PlayerEntityModel<LivingEntity> model(boolean thin) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (thin) {
			if (slim == null) slim = new PlayerEntityModel<>(mc.getEntityModelLoader().getModelPart(EntityModelLayers.PLAYER_SLIM), true);
			return slim;
		}
		if (classic == null) classic = new PlayerEntityModel<>(mc.getEntityModelLoader().getModelPart(EntityModelLayers.PLAYER), false);
		return classic;
	}

	private static void zero(ModelPart p) {
		p.pitch = 0f;
		p.yaw = 0f;
		p.roll = 0f;
	}

	/**
	 * @param x         центр по горизонтали
	 * @param feetY     где стоят ноги
	 * @param pxHeight  рост модели в пикселях интерфейса
	 * @param bodyYaw   поворот всего тела (0 — лицом к нам)
	 * @param headYaw   поворот головы относительно тела, градусы
	 */
	public static void draw(DrawContext ctx, int x, int feetY, int pxHeight, float bodyYaw, float bodyPitch,
							float headYaw, float headPitch, Identifier skin, boolean thin, @Nullable Identifier cape,
							boolean outer, Pose pose, float time) {
		PlayerEntityModel<LivingEntity> m = model(thin);
		for (ModelPart p : new ModelPart[]{m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg}) zero(p);
		m.head.yaw = headYaw * DEG;
		m.head.pitch = headPitch * DEG;
		float breathe = (float) Math.sin(time * 0.067f) * 0.03f;
		m.rightArm.roll = 0.06f + breathe;
		m.leftArm.roll = -0.06f - breathe;
		switch (pose) {
			case WALK -> {
				float s = (float) Math.cos(time * 0.3f);
				m.rightLeg.pitch = s * 0.8f;
				m.leftLeg.pitch = -s * 0.8f;
				m.rightArm.pitch = -s * 0.6f;
				m.leftArm.pitch = s * 0.6f;
			}
			case WAVE -> {
				m.rightArm.pitch = -2.7f;
				m.rightArm.roll = (float) Math.sin(time * 0.4f) * 0.35f;
			}
			case SIT -> {
				m.rightLeg.pitch = -1.41f;
				m.leftLeg.pitch = -1.41f;
				m.rightLeg.yaw = 0.31f;
				m.leftLeg.yaw = -0.31f;
				m.rightArm.pitch = -0.63f;
				m.leftArm.pitch = -0.63f;
			}
			default -> {
			}
		}
		m.hat.copyTransform(m.head);
		m.jacket.copyTransform(m.body);
		m.rightSleeve.copyTransform(m.rightArm);
		m.leftSleeve.copyTransform(m.leftArm);
		m.rightPants.copyTransform(m.rightLeg);
		m.leftPants.copyTransform(m.leftLeg);
		m.hat.visible = outer;
		m.jacket.visible = outer;
		m.rightSleeve.visible = outer;
		m.leftSleeve.visible = outer;
		m.rightPants.visible = outer;
		m.leftPants.visible = outer;

		float size = pxHeight / 2f;
		MatrixStack ms = ctx.getMatrices();
		ms.push();
		ms.translate(x, feetY, 150f);
		ms.scale(size, size, -size);
		ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180f));
		ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(bodyPitch));
		ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(bodyYaw));
		ms.scale(-1f, -1f, 1f);
		ms.translate(0f, -1.501f, 0f);
		if (pose == Pose.SIT) ms.translate(0f, 0.62f, 0f);

		DiffuseLighting.disableGuiDepthLighting();
		VertexConsumerProvider.Immediate imm = ctx.getVertexConsumers();
		m.render(ms, imm.getBuffer(RenderLayer.getEntityTranslucent(skin)), LIGHT, OverlayTexture.DEFAULT_UV, 1f, 1f, 1f, 1f);
		if (cape != null) {
			ms.push();
			ms.translate(0f, 0f, 0.125f);
			float swing = pose == Pose.WALK ? 20f + (float) Math.sin(time * 0.3f) * 6f : 6f;
			ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(swing));
			ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f));
			m.renderCape(ms, imm.getBuffer(RenderLayer.getEntitySolid(cape)), LIGHT, OverlayTexture.DEFAULT_UV);
			ms.pop();
		}
		ctx.draw();
		ms.pop();
		DiffuseLighting.enableGuiDepthLighting();
	}
}
