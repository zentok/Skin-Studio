package com.skinstudio.client;

import com.skinstudio.SkinStudio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

/** Готовые детали для скина + свои PNG из папки SkinStudio/stickers. */
public final class Stickers {
	public record Sticker(String name, PixelImage img, boolean custom) {
	}

	private static final Map<Character, Integer> COLORS = Map.ofEntries(
			Map.entry('k', 0xFF1A1A1A), Map.entry('c', 0xFF8FD3F5), Map.entry('w', 0xFFFFFFFF),
			Map.entry('b', 0xFF5A3A24), Map.entry('n', 0xFF3B2618), Map.entry('r', 0xFFC0392B),
			Map.entry('p', 0xFFF08FA0), Map.entry('y', 0xFFF2C233), Map.entry('g', 0xFF7A7A7A),
			Map.entry('m', 0xFFDDE6EE), Map.entry('v', 0xFF8E44AD), Map.entry('e', 0xFF2E7D32));

	private Stickers() {
	}

	private static Sticker of(String name, String... rows) {
		int w = 0;
		for (String r : rows) w = Math.max(w, r.length());
		PixelImage img = new PixelImage(w, rows.length);
		for (int y = 0; y < rows.length; y++)
			for (int x = 0; x < rows[y].length(); x++) {
				Integer c = COLORS.get(rows[y].charAt(x));
				if (c != null) img.set(x, y, c);
			}
		return new Sticker(name, img, false);
	}

	private static final List<Sticker> BUILT_IN = List.of(
			of("Очки", ".kk..kk.", "kcckkcck", ".kk..kk."),
			of("Тёмные очки", "kkkkkkkk", ".kkk.kk.", ".kk..kk."),
			of("Борода", "b......b", "bb.bb.bb", "bbbbbbbb", ".bbbbbb."),
			of("Усы", ".bbbbbb.", "b......b"),
			of("Шрам", "r...", ".r..", "..r.", "...r"),
			of("Румянец", "p......p"),
			of("Маска", "mmmmmmmm", "mmmmmmmm", ".mmmmmm."),
			of("Повязка", "rrrrrrrr", "r.r..r.r"),
			of("Корона", "y.y..y.y", "yyyyyyyy"),
			of("Цилиндр", "kkkkkkkk", "kkkkkkkk", "rrrrrrrr"),
			of("Пояс", "nnnyynnn"),
			of("Звезда", "..y..", "yyyyy", ".yyy.", "y...y"),
			of("Сердце", ".r.r.", "rrrrr", ".rrr.", "..r.."),
			of("Листик", "..e", ".ee", "ee."),
			of("Галстук", ".v.", "vvv", ".v.", ".v.", "vvv"));

	public static List<Sticker> all() {
		List<Sticker> out = new ArrayList<>(BUILT_IN);
		Path dir = SkinLibrary.get().stickersDir;
		if (Files.isDirectory(dir)) {
			try (Stream<Path> s = Files.list(dir)) {
				s.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png")).sorted().forEach(p -> {
					try {
						PixelImage img = PixelImage.read(p);
						if (img.w <= 64 && img.h <= 64) {
							String f = p.getFileName().toString();
							out.add(new Sticker(f.substring(0, f.length() - 4), img, true));
						}
					} catch (IOException e) {
						SkinStudio.LOGGER.warn("Не удалось прочитать наклейку " + p, e);
					}
				});
			} catch (IOException ignored) {
			}
		}
		return out;
	}
}
