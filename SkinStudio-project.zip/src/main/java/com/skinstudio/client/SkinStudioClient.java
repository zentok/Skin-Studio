package com.skinstudio.client;

import com.skinstudio.SkinNetworking;
import com.skinstudio.SkinStudio;
import com.skinstudio.client.gui.MirrorScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.math.BlockPos;

import java.util.UUID;

public class SkinStudioClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		BlockRenderLayerMap.INSTANCE.putBlock(SkinStudio.WARDROBE_MIRROR, RenderLayer.getCutout());

		ClientPlayNetworking.registerGlobalReceiver(SkinNetworking.OPEN_MIRROR, (client, handler, buf, sender) -> {
			BlockPos pos = buf.readBlockPos();
			client.execute(() -> client.setScreen(new MirrorScreen(pos)));
		});

		ClientPlayNetworking.registerGlobalReceiver(SkinNetworking.SKIN_DATA, (client, handler, buf, sender) -> {
			UUID id = buf.readUuid();
			boolean slim = buf.readBoolean();
			int[] px = readInts(buf, 64 * 64);
			if (px == null) return;
			client.execute(() -> ClientSkins.setSkin(id, slim, px));
		});

		ClientPlayNetworking.registerGlobalReceiver(SkinNetworking.CAPE_DATA, (client, handler, buf, sender) -> {
			UUID id = buf.readUuid();
			boolean has = buf.readBoolean();
			int[] px = has ? readInts(buf, 64 * 32) : null;
			client.execute(() -> ClientSkins.setCape(id, px));
		});

		ClientPlayNetworking.registerGlobalReceiver(SkinNetworking.SKIN_CLEAR, (client, handler, buf, sender) -> {
			UUID id = buf.readUuid();
			client.execute(() -> ClientSkins.clear(id));
		});

		ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> client.execute(ClientSkins::markLocalDirty));
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> client.execute(ClientSkins::clearAll));
		ClientTickEvents.END_CLIENT_TICK.register(ClientSkins::tick);
	}

	private static int[] readInts(PacketByteBuf buf, int n) {
		if (buf.readableBytes() < n * 4) return null;
		int[] px = new int[n];
		for (int i = 0; i < n; i++) px[i] = buf.readInt();
		return px;
	}
}
