package com.skinstudio.client.gui;

import com.skinstudio.HeightHolder;
import com.skinstudio.SkinNetworking;
import com.skinstudio.client.ModelRenderer;
import com.skinstudio.client.SkinLibrary;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;

import java.util.Locale;

/** Шкаф-зеркало в мире: выбрать скин, плащ и рост. Рост в мире меняется только здесь. */
public class MirrorScreen extends Screen {
	private final BlockPos pos;
	private final SkinLibrary lib = SkinLibrary.get();
	private int index;
	private int capeIndex;
	private String status = "";
	private long statusUntil;
	private float rotY = -20f;
	private boolean drag;
	private double dragX;
	private float dragRot;

	public MirrorScreen(BlockPos pos) {
		super(Text.literal("Шкаф-зеркало"));
		this.pos = pos;
		this.index = Math.max(0, lib.indexOf(lib.active));
		this.capeIndex = lib.activeCape.isEmpty() ? -1 : lib.capes.indexOf(lib.activeCape);
	}

	private SkinLibrary.SkinEntry entry() {
		if (lib.skins.isEmpty()) return lib.activeEntry();
		index = Math.floorMod(index, lib.skins.size());
		return lib.skins.get(index);
	}

	private String capeName() {
		if (capeIndex >= lib.capes.size()) capeIndex = -1;
		return capeIndex < 0 ? "" : lib.capes.get(capeIndex);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int x = cx + 10, w = 150;
		int y = this.height / 2 - 66;
		addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
			index--;
			clearAndInit();
		}).dimensions(x, y, 20, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
			index++;
			clearAndInit();
		}).dimensions(x + w - 20, y, 20, 20).build());
		y += 24;
		SkinLibrary.SkinEntry e = entry();
		ValueSlider hs = new ValueSlider(x, y, w, 20, HeightHolder.MIN, HeightHolder.MAX, 0.1f, e.height,
				v -> Text.literal(String.format(Locale.ROOT, "Рост: %.1f бл.", v)), v -> {
			e.height = v;
			lib.saveMeta(e);
		});
		hs.setTooltip(Tooltip.of(Text.literal("Рост сохраняется для этого скина")));
		addDrawableChild(hs);
		y += 24;
		addDrawableChild(ButtonWidget.builder(Text.literal("Плащ: " + (capeName().isEmpty() ? "нет" : capeName())), b -> {
			capeIndex++;
			if (capeIndex >= lib.capes.size()) capeIndex = -1;
			b.setMessage(Text.literal("Плащ: " + (capeName().isEmpty() ? "нет" : capeName())));
		}).dimensions(x, y, w, 20).build());
		y += 28;
		addDrawableChild(ButtonWidget.builder(Text.literal("Надеть"), b -> wear()).dimensions(x, y, w, 20).build());
		y += 24;
		addDrawableChild(ButtonWidget.builder(Text.literal("Изменить скин"), b ->
				client.setScreen(new EditorScreen(this, false, entry().name))).dimensions(x, y, w, 20).build());
		y += 24;
		addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close()).dimensions(x, y, w, 20).build());
	}

	private void wear() {
		SkinLibrary.SkinEntry e = entry();
		lib.setActive(e.name);
		if (!capeName().equals(lib.activeCape)) lib.setActiveCape(capeName());
		if (ClientPlayNetworking.canSend(SkinNetworking.SET_HEIGHT)) {
			PacketByteBuf buf = PacketByteBufs.create();
			buf.writeBlockPos(pos);
			buf.writeFloat(e.height);
			ClientPlayNetworking.send(SkinNetworking.SET_HEIGHT, buf);
			status = String.format(Locale.ROOT, "Надето: %s, рост %.1f бл.", e.name, e.height);
		} else {
			status = "Скин надет. Для роста нужен мод на сервере";
		}
		statusUntil = Util.getMeasuringTimeMs() + 4000;
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (super.mouseClicked(mx, my, button)) return true;
		if (mx < this.width / 2 && button == 0) {
			drag = true;
			dragX = mx;
			dragRot = rotY;
			return true;
		}
		return false;
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (drag) {
			rotY = dragRot + (float) (mx - dragX) * 1.5f;
			return true;
		}
		return super.mouseDragged(mx, my, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		drag = false;
		return super.mouseReleased(mx, my, button);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		this.renderBackground(ctx);
		int cx = this.width / 2;
		ctx.drawCenteredTextWithShadow(textRenderer, this.title, cx, 12, 0xFFFFD45A);
		SkinLibrary.SkinEntry e = entry();

		int fx0 = cx - 160, fy0 = this.height / 2 - 90, fw = 160, fh = 180;
		ctx.fill(fx0 - 3, fy0 - 3, fx0 + fw + 3, fy0 + fh + 3, 0xFF5A3A24);
		ctx.fill(fx0, fy0, fx0 + fw, fy0 + fh, 0xFFBFD6E6);
		ctx.enableScissor(fx0, fy0, fx0 + fw, fy0 + fh);
		int pxH = (int) ((fh - 24) * e.height / HeightHolder.MAX);
		float t = (Util.getMeasuringTimeMs() % 3600000L) / 50f;
		ModelRenderer.draw(ctx, fx0 + fw / 2, fy0 + fh - 10, pxH, rotY, 0f, 0f, 0f,
				lib.skinTextureFor(e.name), e.slim, lib.capeTextureFor(capeName()), true, ModelRenderer.Pose.STAND, t);
		ctx.disableScissor();

		String label = e.name + " (" + (index + 1) + "/" + lib.skins.size() + ")";
		ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(label), cx + 85, this.height / 2 - 60, 0xFFFFFFFF);
		if (client.player != null) {
			float now = ((HeightHolder) client.player).skinstudio$getHeight();
			ctx.drawTextWithShadow(textRenderer, String.format(Locale.ROOT, "Сейчас: %.1f бл.", now), fx0, fy0 + fh + 6, 0xFFCFD8DC);
		}
		if (Util.getMeasuringTimeMs() < statusUntil)
			ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(status), cx, this.height - 20, 0xFF97C459);
		super.render(ctx, mouseX, mouseY, delta);
	}
}
