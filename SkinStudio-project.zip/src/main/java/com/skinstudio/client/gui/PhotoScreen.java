package com.skinstudio.client.gui;

import com.skinstudio.SkinStudio;
import com.skinstudio.client.ModelRenderer;
import com.skinstudio.client.SkinLibrary;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Фотостудия: позы, фоны, поворот и сохранение картинки скина в PNG. */
public class PhotoScreen extends Screen {
	private record Background(String name, int sky, int ground) {
	}

	private static final Background[] BACKGROUNDS = {
			new Background("Луг", 0xFF7FB0D8, 0xFF5A8A3A),
			new Background("Пустыня", 0xFFF0C98A, 0xFFD9B46A),
			new Background("Незер", 0xFF5A1F1F, 0xFF7A2A20),
			new Background("Снег", 0xFFC9DDEB, 0xFFF4F7FA),
			new Background("Ночь", 0xFF1B2440, 0xFF2E4A2A),
			new Background("Студия", 0xFF3A3D44, 0xFF2C2F36)};

	private final Screen parent;
	private final Identifier skin;
	private final boolean slim;
	@Nullable
	private final Identifier cape;
	private final float playerHeight;
	private int pose = 0, bg = 0;
	private float rotY = -25f, zoom = 1f;
	private boolean capture;
	private String status = "";
	private long statusUntil;
	private int ax, ay, aw, ah;

	public PhotoScreen(Screen parent, Identifier skin, boolean slim, @Nullable Identifier cape, float playerHeight) {
		super(Text.literal("Фотостудия"));
		this.parent = parent;
		this.skin = skin;
		this.slim = slim;
		this.cape = cape;
		this.playerHeight = playerHeight;
	}

	@Override
	protected void init() {
		ax = 10;
		ay = 26;
		aw = this.width - 190;
		ah = this.height - 36;
		int x = this.width - 170, w = 160, y = 30;
		ModelRenderer.Pose[] poses = ModelRenderer.Pose.values();
		addDrawableChild(ButtonWidget.builder(Text.literal("Поза: " + poses[pose].title), b -> {
			pose = (pose + 1) % poses.length;
			b.setMessage(Text.literal("Поза: " + poses[pose].title));
		}).dimensions(x, y, w, 20).build());
		y += 24;
		addDrawableChild(ButtonWidget.builder(Text.literal("Фон: " + BACKGROUNDS[bg].name()), b -> {
			bg = (bg + 1) % BACKGROUNDS.length;
			b.setMessage(Text.literal("Фон: " + BACKGROUNDS[bg].name()));
		}).dimensions(x, y, w, 20).build());
		y += 24;
		addDrawableChild(new ValueSlider(x, y, w, 20, -180f, 180f, 5f, rotY,
				v -> Text.literal(String.format(Locale.ROOT, "Поворот: %d°", Math.round(v))), v -> rotY = v));
		y += 24;
		addDrawableChild(new ValueSlider(x, y, w, 20, 0.6f, 1.6f, 0.1f, zoom,
				v -> Text.literal(String.format(Locale.ROOT, "Масштаб: %.1f", v)), v -> zoom = v));
		y += 30;
		addDrawableChild(ButtonWidget.builder(Text.literal("Сохранить PNG"), b -> capture = true).dimensions(x, y, w, 20).build());
		y += 24;
		addDrawableChild(ButtonWidget.builder(Text.literal("Открыть папку фото"), b ->
				Util.getOperatingSystem().open(SkinLibrary.get().photosDir.toFile())).dimensions(x, y, w, 20).build());
		y += 24;
		addDrawableChild(ButtonWidget.builder(Text.literal("Назад"), b -> close()).dimensions(x, y, w, 20).build());
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		this.renderBackground(ctx);
		Background b = BACKGROUNDS[bg];
		int groundH = ah / 5;
		ctx.fill(ax, ay, ax + aw, ay + ah - groundH, b.sky());
		ctx.fill(ax, ay + ah - groundH, ax + aw, ay + ah, b.ground());
		ctx.enableScissor(ax, ay, ax + aw, ay + ah);
		int pxH = (int) ((ah - groundH / 2 - 20) * zoom * playerHeight / 2.5f);
		float t = (Util.getMeasuringTimeMs() % 3600000L) / 50f;
		ModelRenderer.draw(ctx, ax + aw / 2, ay + ah - groundH / 2, pxH, rotY, 0f, 0f, 0f, skin, slim, cape, true,
				ModelRenderer.Pose.values()[pose], t);
		ctx.disableScissor();
		ctx.draw();
		if (capture) {
			capture = false;
			takePhoto();
		}
		ctx.drawTextWithShadow(textRenderer, Text.literal("Фотостудия"), 10, 10, 0xFFFFD45A);
		if (Util.getMeasuringTimeMs() < statusUntil)
			ctx.drawTextWithShadow(textRenderer, status, ax + 4, ay + 4, 0xFFFFFFFF);
		super.render(ctx, mouseX, mouseY, delta);
	}

	private void takePhoto() {
		try (NativeImage shot = ScreenshotRecorder.takeScreenshot(client.getFramebuffer())) {
			double s = client.getWindow().getScaleFactor();
			int x0 = (int) Math.round(ax * s), y0 = (int) Math.round(ay * s);
			int w = Math.min((int) Math.round(aw * s), shot.getWidth() - x0);
			int h = Math.min((int) Math.round(ah * s), shot.getHeight() - y0);
			if (w <= 0 || h <= 0) return;
			Path dir = SkinLibrary.get().photosDir;
			Files.createDirectories(dir);
			Path out = dir.resolve("skin_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss")) + ".png");
			try (NativeImage img = new NativeImage(w, h, false)) {
				for (int y = 0; y < h; y++)
					for (int x = 0; x < w; x++) img.setColor(x, y, shot.getColor(x0 + x, y0 + y) | 0xFF000000);
				img.writeTo(out);
			}
			status = "Сохранено: SkinStudio/photos/" + out.getFileName();
		} catch (Exception e) {
			SkinStudio.LOGGER.error("Не удалось сохранить фото", e);
			status = "Не удалось сохранить фото";
		}
		statusUntil = Util.getMeasuringTimeMs() + 4000;
	}

	@Override
	public void close() {
		client.setScreen(parent);
	}
}
