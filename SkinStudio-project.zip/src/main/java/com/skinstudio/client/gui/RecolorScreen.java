package com.skinstudio.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.skinstudio.client.ColorUtil;
import com.skinstudio.client.DynTex;
import com.skinstudio.client.ModelRenderer;
import com.skinstudio.client.PixelImage;
import com.skinstudio.client.SkinLayout;
import com.skinstudio.client.SkinLibrary;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/** Перекраска части или всего скина: оттенок, насыщенность, яркость. Тени и блики сохраняются. */
public class RecolorScreen extends Screen {
	private record Group(String name, int[] boxes) {
	}

	private static final List<Group> SKIN_GROUPS = List.of(
			new Group("Весь скин", null),
			new Group("Голова", new int[]{SkinLayout.HEAD}),
			new Group("Торс", new int[]{SkinLayout.BODY}),
			new Group("Руки", new int[]{SkinLayout.R_ARM, SkinLayout.L_ARM}),
			new Group("Ноги", new int[]{SkinLayout.R_LEG, SkinLayout.L_LEG}),
			new Group("Внешний слой", new int[]{SkinLayout.HAT, SkinLayout.JACKET, SkinLayout.R_SLEEVE,
					SkinLayout.L_SLEEVE, SkinLayout.R_PANTS, SkinLayout.L_PANTS}));
	private static final List<Group> CAPE_GROUPS = List.of(new Group("Весь плащ", null));

	private final Screen parent;
	private final PixelImage source;
	private PixelImage result;
	private final boolean cape;
	private final boolean slim;
	private final Consumer<PixelImage> onApply;
	private final Consumer<PixelImage> onCopy;
	private int group = 0;
	private float hue = 0f, sat = 0f, val = 0f;
	private final DynTex preview = new DynTex("recolor/preview");
	private boolean dirty = true;
	private float rotY = -25f;
	private boolean drag;
	private double dragX;
	private float dragRot;

	public RecolorScreen(Screen parent, PixelImage source, boolean cape, boolean slim,
						 Consumer<PixelImage> onApply, Consumer<PixelImage> onCopy) {
		super(Text.literal("Перекраска"));
		this.parent = parent;
		this.source = source;
		this.result = source.copy();
		this.cape = cape;
		this.slim = slim;
		this.onApply = onApply;
		this.onCopy = onCopy;
	}

	private List<Group> groups() {
		return cape ? CAPE_GROUPS : SKIN_GROUPS;
	}

	private void recompute() {
		result = source.copy();
		Group g = groups().get(group);
		List<SkinLayout.Box> boxes = cape ? SkinLayout.CAPE : SkinLayout.skinBoxes(slim);
		if (g.boxes() == null) {
			for (int i = 0; i < result.p.length; i++) result.p[i] = ColorUtil.adjust(result.p[i], hue, sat, val);
		} else {
			for (int bi : g.boxes()) {
				SkinLayout.Box b = boxes.get(bi);
				for (int f = 0; f < 6; f++) {
					int[] r = b.face(f);
					for (int y = r[1]; y < r[1] + r[3]; y++)
						for (int x = r[0]; x < r[0] + r[2]; x++) result.set(x, y, ColorUtil.adjust(result.get(x, y), hue, sat, val));
				}
			}
		}
		dirty = true;
	}

	@Override
	protected void init() {
		int x = this.width - 168, w = 160, y = 30;
		addDrawableChild(ButtonWidget.builder(Text.literal("Часть: " + groups().get(group).name()), b -> {
			group = (group + 1) % groups().size();
			b.setMessage(Text.literal("Часть: " + groups().get(group).name()));
			recompute();
		}).dimensions(x, y, w, 20).build());
		y += 24;
		addDrawableChild(new ValueSlider(x, y, w, 20, -180f, 180f, 1f, hue,
				v -> Text.literal(String.format(Locale.ROOT, "Оттенок: %+d°", Math.round(v))), v -> {
			hue = v;
			recompute();
		}));
		y += 24;
		addDrawableChild(new ValueSlider(x, y, w, 20, -100f, 100f, 1f, sat,
				v -> Text.literal(String.format(Locale.ROOT, "Насыщенность: %+d%%", Math.round(v))), v -> {
			sat = v;
			recompute();
		}));
		y += 24;
		addDrawableChild(new ValueSlider(x, y, w, 20, -100f, 100f, 1f, val,
				v -> Text.literal(String.format(Locale.ROOT, "Яркость: %+d%%", Math.round(v))), v -> {
			val = v;
			recompute();
		}));
		y += 30;
		addDrawableChild(ButtonWidget.builder(Text.literal("Применить"), b -> {
			onApply.accept(result.copy());
			client.setScreen(parent);
		}).dimensions(x, y, w, 20).build());
		y += 24;
		addDrawableChild(ButtonWidget.builder(Text.literal("Сохранить как копию"), b -> {
			onCopy.accept(result.copy());
			client.setScreen(parent);
		}).dimensions(x, y, w, 20).build());
		y += 24;
		addDrawableChild(ButtonWidget.builder(Text.literal("Сбросить"), b -> {
			hue = 0f;
			sat = 0f;
			val = 0f;
			recompute();
			clearAndInit();
		}).dimensions(x, y, 78, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Отмена"), b -> close()).dimensions(x + 82, y, 78, 20).build());
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (super.mouseClicked(mx, my, button)) return true;
		if (mx < this.width - 176 && button == 0) {
			drag = true;
			dragX = mx;
			dragRot = rotY;
			return true;
		}
		return false;
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (drag) {
			rotY = dragRot + (float) (mx - dragX) * 1.5f;
			return true;
		}
		return super.mouseDragged(mx, my, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		drag = false;
		return super.mouseReleased(mx, my, button);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		this.renderBackground(ctx);
		if (dirty || !preview.ready()) {
			preview.update(result);
			dirty = false;
		}
		SkinLibrary lib = SkinLibrary.get();
		ctx.drawTextWithShadow(textRenderer, Text.literal("Перекраска · " + groups().get(group).name()), 10, 10, 0xFFFFD45A);
		int areaW = this.width - 186, areaH = this.height - 40;
		ctx.fill(10, 26, 10 + areaW, 26 + areaH, 0xFF2A3340);
		ctx.enableScissor(10, 26, 10 + areaW, 26 + areaH);
		Identifier skin = cape ? lib.activeSkinTexture() : preview.id;
		Identifier capeId = cape ? preview.id : lib.activeCapeTexture();
		boolean thin = cape ? lib.activeEntry().slim : slim;
		float t = (Util.getMeasuringTimeMs() % 3600000L) / 50f;
		int pxH = Math.min(areaH - 30, 200);
		ModelRenderer.draw(ctx, 10 + areaW / 2, 26 + areaH - 12, pxH, rotY + (cape ? 180f : 0f), 0f, 0f, 0f,
				skin, thin, capeId, true, ModelRenderer.Pose.STAND, t);
		ctx.disableScissor();

		int cell = 2;
		int ux = this.width - 168, uy = this.height - 8 - result.h * cell;
		if (uy > 30 + 7 * 24 + 6) {
			RenderSystem.enableBlend();
			ctx.fill(ux - 1, uy - 1, ux + 64 * cell + 1, uy + result.h * cell + 1, 0xFF101114);
			ctx.drawTexture(preview.id, ux, uy, 64 * cell, result.h * cell, 0f, 0f, result.w, result.h, result.w, result.h);
			RenderSystem.disableBlend();
		}
		super.render(ctx, mouseX, mouseY, delta);
	}

	@Override
	public void close() {
		client.setScreen(parent);
	}
}
