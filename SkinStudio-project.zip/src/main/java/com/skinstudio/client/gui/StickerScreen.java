package com.skinstudio.client.gui;

import com.skinstudio.client.PixelImage;
import com.skinstudio.client.SkinLibrary;
import com.skinstudio.client.Stickers;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Выбор наклейки. Свои PNG кладутся в .minecraft/SkinStudio/stickers. */
public class StickerScreen extends Screen {
	private final Screen parent;
	private final Consumer<Stickers.Sticker> onPick;
	private List<Stickers.Sticker> stickers = new ArrayList<>();
	private final List<ButtonWidget> buttons = new ArrayList<>();
	private int page = 0;
	private int perPage = 1;

	public StickerScreen(Screen parent, Consumer<Stickers.Sticker> onPick) {
		super(Text.literal("Наклейки"));
		this.parent = parent;
		this.onPick = onPick;
	}

	@Override
	protected void init() {
		stickers = Stickers.all();
		buttons.clear();
		int cols = Math.max(1, Math.min(4, (this.width - 20) / 104));
		int rows = Math.max(1, (this.height - 80) / 24);
		perPage = cols * rows;
		int pages = Math.max(1, (stickers.size() + perPage - 1) / perPage);
		page = Math.max(0, Math.min(page, pages - 1));
		int startX = this.width / 2 - cols * 104 / 2;
		for (int i = 0; i < perPage; i++) {
			int idx = page * perPage + i;
			if (idx >= stickers.size()) break;
			Stickers.Sticker s = stickers.get(idx);
			int x = startX + (i % cols) * 104, y = 30 + (i / cols) * 24;
			ButtonWidget b = ButtonWidget.builder(Text.literal(s.name() + (s.custom() ? " *" : "")), w -> {
				onPick.accept(s);
				client.setScreen(parent);
			}).dimensions(x + 22, y, 78, 20).build();
			buttons.add(b);
			addDrawableChild(b);
		}
		int by = this.height - 28;
		if (pages > 1) {
			addDrawableChild(ButtonWidget.builder(Text.literal("<"), w -> {
				page = Math.floorMod(page - 1, pages);
				clearAndInit();
			}).dimensions(this.width / 2 - 160, by, 20, 20).build());
			addDrawableChild(ButtonWidget.builder(Text.literal(">"), w -> {
				page = Math.floorMod(page + 1, pages);
				clearAndInit();
			}).dimensions(this.width / 2 + 140, by, 20, 20).build());
		}
		addDrawableChild(ButtonWidget.builder(Text.literal("Открыть папку наклеек"), w ->
				Util.getOperatingSystem().open(SkinLibrary.get().stickersDir.toFile())).dimensions(this.width / 2 - 134, by, 130, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Назад"), w -> close()).dimensions(this.width / 2 + 4, by, 130, 20).build());
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		this.renderBackground(ctx);
		ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Выбери наклейку · * — свои из папки"), this.width / 2, 12, 0xFFFFD45A);
		super.render(ctx, mouseX, mouseY, delta);
		for (int i = 0; i < buttons.size(); i++) {
			int idx = page * perPage + i;
			if (idx >= stickers.size()) break;
			ButtonWidget b = buttons.get(i);
			PixelImage img = stickers.get(idx).img();
			int box = 20;
			int x0 = b.getX() - 22, y0 = b.getY();
			ctx.fill(x0, y0, x0 + box, y0 + box, 0xFF2B2E34);
			int ps = Math.max(1, Math.min(box / Math.max(1, img.w), box / Math.max(1, img.h)));
			int ox = x0 + (box - img.w * ps) / 2, oy = y0 + (box - img.h * ps) / 2;
			for (int y = 0; y < img.h; y++)
				for (int x = 0; x < img.w; x++) {
					int c = img.get(x, y);
					if ((c >>> 24) == 0) continue;
					ctx.fill(ox + x * ps, oy + y * ps, ox + (x + 1) * ps, oy + (y + 1) * ps, c);
				}
		}
	}

	@Override
	public void close() {
		client.setScreen(parent);
	}
}
