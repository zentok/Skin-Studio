package com.skinstudio.client.gui;

import com.skinstudio.client.ModelRenderer;
import com.skinstudio.client.SkinLibrary;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;

/** Кукла в главном меню: крутится, смотрит на курсор, клик открывает редактор. */
public class DollWidget extends ClickableWidget {
	private static final int BOTTOM_ROW = 13;

	public DollWidget(int x, int y, int width, int height) {
		super(x, y, width, height, Text.literal("Изменить скин"));
	}

	@Override
	protected void renderButton(DrawContext ctx, int mouseX, int mouseY, float delta) {
		MinecraftClient mc = MinecraftClient.getInstance();
		TextRenderer tr = mc.textRenderer;
		SkinLibrary lib = SkinLibrary.get();
		SkinLibrary.SkinEntry e = lib.activeEntry();

		int cx = getX() + width / 2;
		int labelY = getY() + height - BOTTOM_ROW - 11;
		int feetY = labelY - 3;
		int pxHeight = (int) ((height - BOTTOM_ROW - 20) * e.height / 2.5f);
		float t = Util.getMeasuringTimeMs() / 50f;
		float bodyYaw = (float) Math.sin(t * 0.02f) * 25f;
		int eyeY = feetY - pxHeight + pxHeight / 8;
		float f = (float) Math.atan((cx - mouseX) / 40.0);
		float g = (float) Math.atan((eyeY - mouseY) / 40.0);
		float headYaw = MathHelper.clamp(bodyYaw + f * 40f, -70f, 70f);
		float headPitch = MathHelper.clamp(-g * 20f, -30f, 30f);

		ModelRenderer.draw(ctx, cx, feetY, pxHeight, bodyYaw, 0f, headYaw, headPitch,
				lib.activeSkinTexture(), e.slim, lib.activeCapeTexture(), true, ModelRenderer.Pose.STAND, t);

		boolean hover = this.isHovered() && mouseY < getY() + height - BOTTOM_ROW;
		Text label = Text.literal("Изменить скин");
		int lw = tr.getWidth(label);
		int color = hover ? 0xFFFFD45A : 0xFFFFFFFF;
		ctx.drawTextWithShadow(tr, label, cx - lw / 2, labelY, color);
		ctx.fill(cx - lw / 2, labelY + 9, cx + lw / 2, labelY + 10, hover ? 0xFFFFD45A : 0x90FFFFFF);

		String name = e.name;
		int maxW = width - 32;
		while (tr.getWidth(name) > maxW && name.length() > 1) name = name.substring(0, name.length() - 1);
		if (!name.equals(e.name)) name = name + "…";
		int nw = tr.getWidth(name);
		ctx.drawTextWithShadow(tr, name, cx - nw / 2, getY() + height - BOTTOM_ROW + 2, 0xFFCFD8DC);
	}

	@Override
	protected boolean clicked(double mouseX, double mouseY) {
		return this.active && this.visible && mouseX >= getX() && mouseX < getX() + width
				&& mouseY >= getY() && mouseY < getY() + height - BOTTOM_ROW;
	}

	@Override
	public void onClick(double mouseX, double mouseY) {
		MinecraftClient mc = MinecraftClient.getInstance();
		mc.setScreen(new EditorScreen(mc.currentScreen));
	}

	@Override
	protected void appendClickableNarrations(NarrationMessageBuilder builder) {
		this.appendDefaultNarrations(builder);
	}
}
