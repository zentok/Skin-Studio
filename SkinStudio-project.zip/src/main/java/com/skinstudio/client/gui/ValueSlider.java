package com.skinstudio.client.gui;

import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.Function;

/** Ползунок с минимумом, максимумом и шагом. */
public class ValueSlider extends SliderWidget {
	private final float min;
	private final float max;
	private final float step;
	private final Function<Float, Text> label;
	private final Consumer<Float> onChange;

	public ValueSlider(int x, int y, int width, int height, float min, float max, float step, float value,
					   Function<Float, Text> label, Consumer<Float> onChange) {
		super(x, y, width, height, Text.empty(), (Math.max(min, Math.min(max, value)) - min) / (max - min));
		this.min = min;
		this.max = max;
		this.step = step;
		this.label = label;
		this.onChange = onChange;
		this.updateMessage();
	}

	public float get() {
		float v = min + (float) this.value * (max - min);
		v = Math.round(v / step) * step;
		return Math.max(min, Math.min(max, v));
	}

	public void set(float v) {
		this.value = (Math.max(min, Math.min(max, v)) - min) / (max - min);
		this.updateMessage();
	}

	@Override
	protected void updateMessage() {
		if (label != null) this.setMessage(label.apply(get()));
	}

	@Override
	protected void applyValue() {
		if (onChange != null) onChange.accept(get());
	}
}
