package com.skinstudio.client;

import java.util.Locale;

public final class ColorUtil {
	private ColorUtil() {
	}

	public static float[] toHsv(int argb) {
		float r = ((argb >> 16) & 0xFF) / 255f, g = ((argb >> 8) & 0xFF) / 255f, b = (argb & 0xFF) / 255f;
		float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
		float d = max - min;
		float h = 0f;
		if (d > 0f) {
			if (max == r) h = ((g - b) / d) % 6f;
			else if (max == g) h = (b - r) / d + 2f;
			else h = (r - g) / d + 4f;
			h /= 6f;
			if (h < 0f) h += 1f;
		}
		float s = max == 0f ? 0f : d / max;
		return new float[]{h, s, max};
	}

	public static int fromHsv(float h, float s, float v, int alpha) {
		h = ((h % 1f) + 1f) % 1f;
		float c = v * s;
		float x = c * (1f - Math.abs((h * 6f) % 2f - 1f));
		float m = v - c;
		float r, g, b;
		int i = (int) (h * 6f);
		switch (i) {
			case 0 -> { r = c; g = x; b = 0; }
			case 1 -> { r = x; g = c; b = 0; }
			case 2 -> { r = 0; g = c; b = x; }
			case 3 -> { r = 0; g = x; b = c; }
			case 4 -> { r = x; g = 0; b = c; }
			default -> { r = c; g = 0; b = x; }
		}
		int ri = Math.round((r + m) * 255f), gi = Math.round((g + m) * 255f), bi = Math.round((b + m) * 255f);
		return (alpha << 24) | (clamp255(ri) << 16) | (clamp255(gi) << 8) | clamp255(bi);
	}

	private static int clamp255(int v) {
		return Math.max(0, Math.min(255, v));
	}

	/** Сдвиг оттенка (градусы), насыщенности и яркости (проценты), тени сохраняются. */
	public static int adjust(int argb, float dHue, float dSat, float dVal) {
		int a = (argb >>> 24) & 0xFF;
		if (a == 0) return argb;
		float[] hsv = toHsv(argb);
		float h = hsv[0] + dHue / 360f;
		float s = clamp01(hsv[1] * (1f + dSat / 100f));
		float v = clamp01(hsv[2] * (1f + dVal / 100f));
		return fromHsv(h, s, v, a);
	}

	/** Светлее/темнее на шаг. */
	public static int shade(int argb, float delta) {
		float[] hsv = toHsv(argb);
		return fromHsv(hsv[0], hsv[1], clamp01(hsv[2] + delta), (argb >>> 24) & 0xFF);
	}

	public static float clamp01(float v) {
		return Math.max(0f, Math.min(1f, v));
	}

	public static String hex(int argb) {
		return String.format(Locale.ROOT, "#%06X", argb & 0xFFFFFF);
	}

	/** Разбирает #RRGGBB, или возвращает null. */
	public static Integer parseHex(String s) {
		if (s == null) return null;
		String t = s.trim();
		if (t.startsWith("#")) t = t.substring(1);
		if (t.length() != 6) return null;
		try {
			return 0xFF000000 | Integer.parseInt(t, 16);
		} catch (NumberFormatException e) {
			return null;
		}
	}
}
