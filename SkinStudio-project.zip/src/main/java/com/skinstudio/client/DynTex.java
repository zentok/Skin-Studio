package com.skinstudio.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

/** Текстура в видеопамяти, которую можно перерисовывать на лету. */
public final class DynTex {
	public final Identifier id;
	private NativeImageBackedTexture texture;
	private int w = -1;
	private int h = -1;

	public DynTex(String path) {
		this.id = new Identifier("skinstudio", path);
	}

	public boolean ready() {
		return texture != null;
	}

	public void update(PixelImage img) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (texture == null || w != img.w || h != img.h) {
			destroy();
			texture = new NativeImageBackedTexture(new NativeImage(img.w, img.h, true));
			mc.getTextureManager().registerTexture(id, texture);
			w = img.w;
			h = img.h;
		}
		NativeImage ni = texture.getImage();
		if (ni == null) return;
		for (int y = 0; y < img.h; y++)
			for (int x = 0; x < img.w; x++) ni.setColor(x, y, PixelImage.swapRB(img.p[y * img.w + x]));
		texture.upload();
	}

	public void destroy() {
		if (texture != null) {
			MinecraftClient.getInstance().getTextureManager().destroyTexture(id);
			texture = null;
			w = -1;
			h = -1;
		}
	}
}
