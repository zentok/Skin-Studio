package com.skinstudio.client;

import net.minecraft.client.texture.NativeImage;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Простая картинка ARGB в памяти. */
public final class PixelImage {
	public final int w;
	public final int h;
	public final int[] p;

	public PixelImage(int w, int h) {
		this(w, h, new int[w * h]);
	}

	public PixelImage(int w, int h, int[] pixels) {
		this.w = w;
		this.h = h;
		this.p = pixels;
	}

	public boolean inside(int x, int y) {
		return x >= 0 && y >= 0 && x < w && y < h;
	}

	public int get(int x, int y) {
		return inside(x, y) ? p[y * w + x] : 0;
	}

	public void set(int x, int y, int argb) {
		if (inside(x, y)) p[y * w + x] = argb;
	}

	public void fill(int x, int y, int fw, int fh, int argb) {
		for (int yy = y; yy < y + fh; yy++)
			for (int xx = x; xx < x + fw; xx++) set(xx, yy, argb);
	}

	public PixelImage copy() {
		return new PixelImage(w, h, p.clone());
	}

	public void copyFrom(PixelImage other) {
		if (other.w == w && other.h == h) System.arraycopy(other.p, 0, p, 0, p.length);
	}

	/** Ближайший сосед. */
	public PixelImage resized(int nw, int nh) {
		PixelImage out = new PixelImage(nw, nh);
		for (int y = 0; y < nh; y++)
			for (int x = 0; x < nw; x++) out.p[y * nw + x] = get(x * w / nw, y * h / nh);
		return out;
	}

	/** ARGB ⇄ ABGR (формат NativeImage). */
	public static int swapRB(int c) {
		return (c & 0xFF00FF00) | ((c & 0xFF) << 16) | ((c >> 16) & 0xFF);
	}

	public static PixelImage read(Path path) throws IOException {
		try (InputStream in = Files.newInputStream(path);
			 NativeImage ni = NativeImage.read(NativeImage.Format.RGBA, in)) {
			PixelImage img = new PixelImage(ni.getWidth(), ni.getHeight());
			for (int y = 0; y < img.h; y++)
				for (int x = 0; x < img.w; x++) img.p[y * img.w + x] = swapRB(ni.getColor(x, y));
			return img;
		}
	}

	/** Пишет PNG поверх существующего файла с тем же именем (через временный файл). */
	public void write(Path path) throws IOException {
		Path parent = path.toAbsolutePath().getParent();
		if (parent != null) Files.createDirectories(parent);
		Path tmp = path.resolveSibling(path.getFileName().toString() + ".tmp");
		try (NativeImage ni = new NativeImage(w, h, false)) {
			for (int y = 0; y < h; y++)
				for (int x = 0; x < w; x++) ni.setColor(x, y, swapRB(p[y * w + x]));
			ni.writeTo(tmp);
		}
		Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING);
	}
}
