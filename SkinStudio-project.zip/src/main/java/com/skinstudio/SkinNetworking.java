package com.skinstudio;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.S2CPlayChannelEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Сеть: рост (только у зеркала), раздача скинов и плащей всем игрокам с модом.
 */
public final class SkinNetworking {
	public static final Identifier OPEN_MIRROR = SkinStudio.id("open_mirror");
	public static final Identifier SET_HEIGHT = SkinStudio.id("set_height");
	public static final Identifier SKIN_UPLOAD = SkinStudio.id("skin_upload");
	public static final Identifier CAPE_UPLOAD = SkinStudio.id("cape_upload");
	public static final Identifier SKIN_DATA = SkinStudio.id("skin_data");
	public static final Identifier CAPE_DATA = SkinStudio.id("cape_data");
	public static final Identifier SKIN_CLEAR = SkinStudio.id("skin_clear");

	/** 64×64 пикселя по 4 байта. */
	public static final int SKIN_BYTES = 64 * 64 * 4;
	/** 64×32 пикселя по 4 байта. */
	public static final int CAPE_BYTES = 64 * 32 * 4;

	private static final Map<UUID, byte[]> SKINS = new ConcurrentHashMap<>();
	private static final Map<UUID, byte[]> CAPES = new ConcurrentHashMap<>();

	private SkinNetworking() {
	}

	public static void registerServer() {
		ServerPlayNetworking.registerGlobalReceiver(SET_HEIGHT, (server, player, handler, buf, sender) -> {
			BlockPos pos = buf.readBlockPos();
			float requested = buf.readFloat();
			server.execute(() -> applyHeight(player, pos, requested));
		});

		ServerPlayNetworking.registerGlobalReceiver(SKIN_UPLOAD, (server, player, handler, buf, sender) -> {
			if (buf.readableBytes() != 1 + SKIN_BYTES) return;
			byte[] data = new byte[1 + SKIN_BYTES];
			buf.readBytes(data);
			UUID id = player.getUuid();
			server.execute(() -> {
				SKINS.put(id, data);
				broadcast(server, SKIN_DATA, id, data);
			});
		});

		ServerPlayNetworking.registerGlobalReceiver(CAPE_UPLOAD, (server, player, handler, buf, sender) -> {
			int n = buf.readableBytes();
			if (n != 1 && n != 1 + CAPE_BYTES) return;
			byte[] data = new byte[n];
			buf.readBytes(data);
			UUID id = player.getUuid();
			server.execute(() -> {
				if (data[0] == 0) CAPES.remove(id);
				else CAPES.put(id, data);
				broadcast(server, CAPE_DATA, id, data);
			});
		});

		// Когда клиент сообщил свои каналы — отправляем ему скины всех, кто уже на сервере.
		S2CPlayChannelEvents.REGISTER.register((handler, sender, server, channels) -> {
			if (!channels.contains(SKIN_DATA)) return;
			ServerPlayerEntity player = handler.player;
			// Событие приходит, пока сервер ещё собирает подключение игрока: execute() выполнил бы код сразу,
			// когда сетевой модуль игрока ещё не готов (NPE «Couldn't place player in world»). Ставим в очередь.
			server.send(new net.minecraft.server.ServerTask(server.getTicks(), () -> {
				if (player.isDisconnected()) return;
				for (Map.Entry<UUID, byte[]> e : SKINS.entrySet()) send(player, SKIN_DATA, e.getKey(), e.getValue());
				for (Map.Entry<UUID, byte[]> e : CAPES.entrySet()) send(player, CAPE_DATA, e.getKey(), e.getValue());
			}));
		});

		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			UUID id = handler.player.getUuid();
			server.execute(() -> {
				SKINS.remove(id);
				CAPES.remove(id);
				for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
					if (p.getUuid().equals(id)) continue;
					send(p, SKIN_CLEAR, id, new byte[0]);
				}
			});
		});

		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			SKINS.clear();
			CAPES.clear();
		});
	}

	private static void applyHeight(ServerPlayerEntity player, BlockPos pos, float requested) {
		if (!Float.isFinite(requested)) return;
		if (!player.getWorld().getBlockState(pos).isOf(SkinStudio.WARDROBE_MIRROR)) return;
		if (player.squaredDistanceTo(Vec3d.ofCenter(pos)) > 64.0) {
			player.sendMessage(Text.literal("Подойди ближе к шкафу-зеркалу"), true);
			return;
		}
		HeightHolder holder = (HeightHolder) player;
		float old = holder.skinstudio$getHeight();
		float h = HeightHolder.clamp(requested);
		if (Math.abs(old - h) < 0.001f) return;
		holder.skinstudio$setHeight(h);
		player.calculateDimensions();
		if (!player.getWorld().isSpaceEmpty(player)) {
			holder.skinstudio$setHeight(old);
			player.calculateDimensions();
			player.sendMessage(Text.literal("Здесь не хватает места для такого роста"), true);
			return;
		}
		player.sendMessage(Text.literal(String.format(java.util.Locale.ROOT, "Рост: %.1f бл.", h)), true);
	}

	private static void broadcast(MinecraftServer server, Identifier channel, UUID id, byte[] data) {
		for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) send(p, channel, id, data);
	}

	private static void send(ServerPlayerEntity player, Identifier channel, UUID id, byte[] data) {
		try {
			if (!ServerPlayNetworking.canSend(player, channel)) return;
		} catch (RuntimeException ex) {
			return; // подключение игрока ещё не готово или уже закрыто
		}
		PacketByteBuf out = PacketByteBufs.create();
		out.writeUuid(id);
		out.writeBytes(data);
		ServerPlayNetworking.send(player, channel, out);
	}

	public static void openMirror(ServerPlayerEntity player, BlockPos pos) {
		if (!ServerPlayNetworking.canSend(player, OPEN_MIRROR)) {
			player.sendMessage(Text.literal("Для шкафа-зеркала нужен мод Skin Studio"), true);
			return;
		}
		PacketByteBuf buf = PacketByteBufs.create();
		buf.writeBlockPos(pos);
		ServerPlayNetworking.send(player, OPEN_MIRROR, buf);
	}
}
