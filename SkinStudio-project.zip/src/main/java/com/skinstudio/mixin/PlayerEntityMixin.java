package com.skinstudio.mixin;

import com.skinstudio.HeightHolder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Настоящий рост игрока: хитбокс, высота глаз (камера), сохранение в данных игрока.
 * Значение синхронизируется с клиентами через DataTracker.
 */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin extends LivingEntity implements HeightHolder {
	@Unique
	private static final TrackedData<Float> SKINSTUDIO_HEIGHT =
			DataTracker.registerData(PlayerEntity.class, TrackedDataHandlerRegistry.FLOAT);

	@Unique
	private float skinstudio$lastHeight = HeightHolder.DEFAULT;

	protected PlayerEntityMixin(EntityType<? extends LivingEntity> entityType, World world) {
		super(entityType, world);
	}

	@Inject(method = "initDataTracker", at = @At("TAIL"))
	private void skinstudio$initTracker(CallbackInfo ci) {
		this.dataTracker.startTracking(SKINSTUDIO_HEIGHT, HeightHolder.DEFAULT);
	}

	@Override
	public float skinstudio$getHeight() {
		try {
			Float v = this.dataTracker.get(SKINSTUDIO_HEIGHT);
			return v == null ? HeightHolder.DEFAULT : v;
		} catch (Throwable t) {
			return HeightHolder.DEFAULT;
		}
	}

	@Override
	public void skinstudio$setHeight(float height) {
		this.dataTracker.set(SKINSTUDIO_HEIGHT, HeightHolder.clamp(height));
	}

	@Inject(method = "tick", at = @At("HEAD"))
	private void skinstudio$tick(CallbackInfo ci) {
		float h = skinstudio$getHeight();
		if (h != skinstudio$lastHeight) {
			skinstudio$lastHeight = h;
			this.calculateDimensions();
		}
	}

	@Inject(method = "getDimensions", at = @At("RETURN"), cancellable = true)
	private void skinstudio$dimensions(EntityPose pose, CallbackInfoReturnable<EntityDimensions> cir) {
		float h = skinstudio$getHeight();
		if (Math.abs(h - HeightHolder.DEFAULT) < 0.001f) return;
		float scale = h / HeightHolder.DEFAULT;
		EntityDimensions base = cir.getReturnValue();
		float width = base.width * scale;
		float height = base.height * scale;
		if (pose == EntityPose.CROUCHING) height = Math.min(height, HeightHolder.MAX_CROUCH);
		cir.setReturnValue(EntityDimensions.changing(width, height));
	}

	@Inject(method = "getActiveEyeHeight", at = @At("RETURN"), cancellable = true)
	private void skinstudio$eyeHeight(EntityPose pose, EntityDimensions dimensions, CallbackInfoReturnable<Float> cir) {
		float h = skinstudio$getHeight();
		if (Math.abs(h - HeightHolder.DEFAULT) < 0.001f) return;
		// без switch по enum: в миксинах он создаёт синтетический класс
		float vanillaHeight;
		if (pose == EntityPose.CROUCHING) vanillaHeight = 1.5f;
		else if (pose == EntityPose.SWIMMING || pose == EntityPose.FALL_FLYING || pose == EntityPose.SPIN_ATTACK) vanillaHeight = 0.6f;
		else if (pose == EntityPose.SLEEPING || pose == EntityPose.DYING) vanillaHeight = 0.2f;
		else vanillaHeight = 1.8f;
		float ratio = dimensions.height / vanillaHeight;
		cir.setReturnValue(cir.getReturnValue() * ratio);
	}

	@Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
	private void skinstudio$writeNbt(NbtCompound nbt, CallbackInfo ci) {
		nbt.putFloat("SkinStudioHeight", skinstudio$getHeight());
	}

	@Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
	private void skinstudio$readNbt(NbtCompound nbt, CallbackInfo ci) {
		if (nbt.contains("SkinStudioHeight")) skinstudio$setHeight(nbt.getFloat("SkinStudioHeight"));
	}
}
