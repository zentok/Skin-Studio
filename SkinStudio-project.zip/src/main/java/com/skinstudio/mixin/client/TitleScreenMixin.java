package com.skinstudio.mixin.client;

import com.skinstudio.client.SkinLibrary;
import com.skinstudio.client.gui.DollWidget;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Кукла со скином справа (или слева) от кнопок главного меню. */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
	protected TitleScreenMixin(Text title) {
		super(title);
	}

	@Inject(method = "init", at = @At("TAIL"))
	private void skinstudio$addDoll(CallbackInfo ci) {
		SkinLibrary lib = SkinLibrary.get();
		// справа от «Выход» стоит кнопка спец. возможностей (до +124), слева кнопка языка (от -124)
		int gap = 14;
		int side = this.width / 2 - 124 - gap;
		int w = Math.max(60, Math.min(110, side - 4));
		int x = lib.dollLeft ? this.width / 2 - 124 - gap - w : this.width / 2 + 124 + gap;
		x = Math.max(4, Math.min(this.width - w - 4, x));
		// по высоте — от первой кнопки меню до низа экрана
		// снизу оставляем место под строку версии и Copyright (она на height - 10)
		int bottomLimit = this.height - 14;
		int y = this.height / 4 + 48 - 24;
		int h = Math.max(80, Math.min(190, bottomLimit - y));
		if (y + h > bottomLimit) y = Math.max(2, bottomLimit - h);
		int arrowsY = y + h - 12;
		// стрелки добавляем первыми, чтобы клик по ним не открывал редактор
		this.addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> lib.cycle(-1))
				.dimensions(x, arrowsY, 14, 12).build());
		this.addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> lib.cycle(1))
				.dimensions(x + w - 14, arrowsY, 14, 12).build());
		this.addDrawableChild(new DollWidget(x, y, w, h));
	}
}
