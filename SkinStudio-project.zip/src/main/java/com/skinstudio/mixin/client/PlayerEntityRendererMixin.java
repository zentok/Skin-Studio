package com.skinstudio.mixin.client;

import com.skinstudio.HeightHolder;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Модель игрока растёт вместе с хитбоксом. */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {
	@Inject(method = "scale(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/util/math/MatrixStack;F)V",
			at = @At("TAIL"))
	private void skinstudio$scale(AbstractClientPlayerEntity player, MatrixStack matrices, float amount, CallbackInfo ci) {
		float s = ((HeightHolder) player).skinstudio$getHeight() / HeightHolder.DEFAULT;
		if (Math.abs(s - 1f) > 0.001f) matrices.scale(s, s, s);
	}
}
