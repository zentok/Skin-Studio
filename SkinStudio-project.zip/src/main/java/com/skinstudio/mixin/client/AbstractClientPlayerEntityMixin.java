package com.skinstudio.mixin.client;

import com.skinstudio.client.ClientSkins;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Подменяет скин и плащ игрока на нарисованные в Skin Studio. */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
	@Unique
	private ClientSkins.Entry skinstudio$entry() {
		return ClientSkins.get(((Entity) (Object) this).getUuid());
	}

	@Inject(method = "getSkinTexture", at = @At("HEAD"), cancellable = true)
	private void skinstudio$skin(CallbackInfoReturnable<Identifier> cir) {
		ClientSkins.Entry e = skinstudio$entry();
		if (e != null && e.hasSkin()) cir.setReturnValue(e.skinId());
	}

	@Inject(method = "getModel", at = @At("HEAD"), cancellable = true)
	private void skinstudio$model(CallbackInfoReturnable<String> cir) {
		ClientSkins.Entry e = skinstudio$entry();
		if (e != null && e.hasSkin()) cir.setReturnValue(e.slim ? "slim" : "default");
	}

	@Inject(method = "getCapeTexture", at = @At("HEAD"), cancellable = true)
	private void skinstudio$cape(CallbackInfoReturnable<Identifier> cir) {
		ClientSkins.Entry e = skinstudio$entry();
		if (e != null && e.hasCape()) cir.setReturnValue(e.capeId());
	}

	@Inject(method = "canRenderCapeTexture", at = @At("HEAD"), cancellable = true)
	private void skinstudio$canCape(CallbackInfoReturnable<Boolean> cir) {
		ClientSkins.Entry e = skinstudio$entry();
		if (e != null && e.hasCape()) cir.setReturnValue(true);
	}
}
