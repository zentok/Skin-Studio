package com.skinstudio.mixin;

import com.skinstudio.HeightHolder;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Рост сохраняется после смерти и при переходе между измерениями. */
@Mixin(ServerPlayerEntity.class)
public abstract class ServerPlayerEntityMixin {
	@Inject(method = "copyFrom", at = @At("TAIL"))
	private void skinstudio$copyHeight(ServerPlayerEntity oldPlayer, boolean alive, CallbackInfo ci) {
		float h = ((HeightHolder) oldPlayer).skinstudio$getHeight();
		((HeightHolder) (Object) this).skinstudio$setHeight(h);
	}
}
