package com.skinstudio;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SkinStudio implements ModInitializer {
	public static final String MOD_ID = "skinstudio";
	public static final Logger LOGGER = LoggerFactory.getLogger("Skin Studio");

	public static final Block WARDROBE_MIRROR = new WardrobeMirrorBlock(
			AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).nonOpaque());
	public static final Item WARDROBE_MIRROR_ITEM = new BlockItem(WARDROBE_MIRROR, new Item.Settings());

	public static Identifier id(String path) {
		return new Identifier(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		Registry.register(Registries.BLOCK, id("wardrobe_mirror"), WARDROBE_MIRROR);
		Registry.register(Registries.ITEM, id("wardrobe_mirror"), WARDROBE_MIRROR_ITEM);
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> entries.add(WARDROBE_MIRROR_ITEM));
		SkinNetworking.registerServer();
		LOGGER.info("Skin Studio загружен");
	}
}
