package com.skinstudio;

/**
 * Рост игрока в блоках. Реализуется миксином в PlayerEntity.
 */
public interface HeightHolder {
	float DEFAULT = 1.8f;
	float MIN = 1.5f;
	float MAX = 2.5f;
	/** Максимальный рост в приседе, чтобы проходить в проёмы высотой 2 блока. */
	float MAX_CROUCH = 1.9f;

	float skinstudio$getHeight();

	void skinstudio$setHeight(float height);

	static float clamp(float h) {
		if (!Float.isFinite(h)) return DEFAULT;
		float r = Math.round(h * 10f) / 10f;
		return Math.max(MIN, Math.min(MAX, r));
	}
}
