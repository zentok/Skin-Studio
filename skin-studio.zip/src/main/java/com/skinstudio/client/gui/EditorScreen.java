package com.skinstudio.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.skinstudio.HeightHolder;
import com.skinstudio.SkinStudio;
import com.skinstudio.client.ColorUtil;
import com.skinstudio.client.DynTex;
import com.skinstudio.client.ModelRenderer;
import com.skinstudio.client.PixelImage;
import com.skinstudio.client.SkinLayout;
import com.skinstudio.client.SkinLibrary;
import com.skinstudio.client.Stickers;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;

/**
 * Редактор: слева 2D развёртка, по центру 3D модель, справа управление.
 * Работает и для скинов (64×64), и для плащей (64×32).
 */
public class EditorScreen extends Screen {
	private enum Tool {
		PEN("Кр", "Карандаш"),
		ERASER("Лс", "Ластик"),
		FILL("Зл", "Заливка грани"),
		PICK("Пп", "Пипетка (также правая кнопка мыши)"),
		CUT("Нк", "Сохранить кусок как наклейку: выдели рамкой");
		final String label, title;

		Tool(String label, String title) {
			this.label = label;
			this.title = title;
		}
	}

	private static final int[] PALETTE = {
			0xFFFFFFFF, 0xFFB0B0B0, 0xFF5F5E5A, 0xFF1A1A1A, 0xFFC99A72, 0xFF8A5A3B, 0xFF4A2F1F, 0xFFE24B4A,
			0xFFF28C28, 0xFFF2C233, 0xFF6FB03F, 0xFF2E7D32, 0xFF2FA89A, 0xFF3B6BD6, 0xFF3A4A8F, 0xFFA24BD4};

	private final Screen parent;
	private final SkinLibrary lib = SkinLibrary.get();
	private boolean capeMode;
	private String editName;
	private PixelImage img;
	private boolean slim;
	private float height = HeightHolder.DEFAULT;
	private boolean dirty;
	private boolean canvasDirty = true;

	private final Deque<int[]> undo = new ArrayDeque<>();
	private final Deque<int[]> redo = new ArrayDeque<>();
	private Tool tool = Tool.PEN;
	private int color = 0xFF3B6BD6;
	private boolean mirror = false;
	private boolean outer = true;

	private int cell = 3, gx, gy, px0, py0, pw, ph, palY;
	private float rotY = -25f, rotX = 0f;
	private boolean painting, dragModel, cutting;
	private int lastX = -1, lastY = -1, cutX, cutY;
	private double dragStartX, dragStartY;
	private float dragRotY, dragRotX;
	@Nullable
	private Stickers.Sticker sticker;

	private final DynTex canvas = new DynTex("editor/canvas");
	private final DynTex checker = new DynTex("editor/checker");
	private TextFieldWidget nameField;
	private TextFieldWidget hexField;
	private boolean ignoreHex;
	private final List<ButtonWidget> toolButtons = new ArrayList<>();
	private ButtonWidget mirrorButton;
	private String status = "";
	private long statusUntil;

	public EditorScreen(Screen parent) {
		this(parent, false, null);
	}

	public EditorScreen(Screen parent, boolean capeMode, @Nullable String name) {
		super(Text.literal("Skin Studio"));
		this.parent = parent;
		this.capeMode = capeMode;
		load(name);
	}

	// ---------------------------------------------------------------- данные

	private void load(@Nullable String name) {
		undo.clear();
		redo.clear();
		sticker = null;
		dirty = false;
		if (capeMode) {
			if (name == null || !lib.capes.contains(name)) name = lib.activeCape;
			if (name == null || name.isEmpty() || !lib.capes.contains(name)) {
				name = lib.capes.isEmpty() ? lib.createCape("Мой плащ", SkinLayout.defaultCape()) : lib.capes.get(0);
			}
			editName = name;
			img = lib.loadCape(name);
			slim = false;
		} else {
			SkinLibrary.SkinEntry e = name != null ? lib.find(name) : null;
			if (e == null) e = lib.activeEntry();
			editName = e.name;
			img = lib.loadSkin(e.name);
			slim = e.slim;
			height = e.height;
		}
		canvasDirty = true;
	}

	private List<SkinLayout.Box> boxes() {
		return capeMode ? SkinLayout.CAPE : SkinLayout.skinBoxes(slim);
	}

	private int[] pairs() {
		return capeMode ? SkinLayout.CAPE_PAIRS : SkinLayout.SKIN_PAIRS;
	}

	private void saveCurrent() {
		String newName = nameField != null ? SkinLibrary.sanitize(nameField.getText()) : editName;
		try {
			if (capeMode) {
				if (!newName.equals(editName)) editName = lib.renameCape(editName, newName);
				lib.saveCape(editName, img);
				if (dirty && editName.equals(lib.activeCape)) lib.applyCape();
			} else {
				SkinLibrary.SkinEntry e = lib.find(editName);
				if (e == null) return;
				if (!newName.equals(e.name)) lib.renameSkin(e, newName);
				editName = e.name;
				e.slim = slim;
				e.height = height;
				lib.saveSkin(e, img);
				if (dirty && e.name.equalsIgnoreCase(lib.active)) lib.applySkin();
			}
			dirty = false;
		} catch (Exception ex) {
			SkinStudio.LOGGER.error("Ошибка сохранения", ex);
			setStatus("Ошибка сохранения: " + ex.getMessage());
		}
	}

	private void setStatus(String s) {
		status = s;
		statusUntil = Util.getMeasuringTimeMs() + 4000;
	}

	private void markChanged() {
		dirty = true;
		canvasDirty = true;
	}

	private void pushUndo() {
		undo.push(img.p.clone());
		while (undo.size() > 60) undo.removeLast();
		redo.clear();
	}

	private void doUndo() {
		if (undo.isEmpty()) return;
		redo.push(img.p.clone());
		System.arraycopy(undo.pop(), 0, img.p, 0, img.p.length);
		markChanged();
	}

	private void doRedo() {
		if (redo.isEmpty()) return;
		undo.push(img.p.clone());
		System.arraycopy(redo.pop(), 0, img.p, 0, img.p.length);
		markChanged();
	}

	// ---------------------------------------------------------------- разметка

	private ButtonWidget btn(String label, int x, int y, int w, int h, ButtonWidget.PressAction action) {
		return ButtonWidget.builder(Text.literal(label), action).dimensions(x, y, w, h).build();
	}

	@Override
	protected void init() {
		toolButtons.clear();
		int panelW = 108;
		int availW = this.width - 28 - panelW - 8 - 96;
		cell = Math.max(2, Math.min(6, Math.min((this.height - 22 - 58) / 64, availW / 64)));
		gx = 28;
		gy = 22;
		int panelX = this.width - panelW - 4;
		px0 = gx + 64 * cell + 6;
		pw = Math.max(60, panelX - 6 - px0);
		py0 = gy;
		ph = 64 * cell;
		palY = gy + 64 * cell + 6;

		// инструменты
		int ty = gy;
		for (Tool t : Tool.values()) {
			ButtonWidget b = ButtonWidget.builder(Text.literal(t.label), x -> {
				tool = t;
				sticker = null;
			}).dimensions(4, ty, 20, 18).tooltip(Tooltip.of(Text.literal(t.title))).build();
			toolButtons.add(b);
			addDrawableChild(b);
			ty += 20;
		}
		mirrorButton = ButtonWidget.builder(Text.literal("Зр"), b -> mirror = !mirror).dimensions(4, ty, 20, 18)
				.tooltip(Tooltip.of(Text.literal("Зеркало: правая и левая сторона рисуются вместе"))).build();
		addDrawableChild(mirrorButton);
		ty += 22;
		addDrawableChild(ButtonWidget.builder(Text.literal("↶"), b -> doUndo()).dimensions(4, ty, 20, 18)
				.tooltip(Tooltip.of(Text.literal("Отменить (Ctrl+Z)"))).build());
		ty += 20;
		addDrawableChild(ButtonWidget.builder(Text.literal("↷"), b -> doRedo()).dimensions(4, ty, 20, 18)
				.tooltip(Tooltip.of(Text.literal("Вернуть (Ctrl+Y)"))).build());
		ty += 22;
		addDrawableChild(ButtonWidget.builder(Text.literal(lib.dollLeft ? "◧" : "◨"), b -> {
			lib.dollLeft = !lib.dollLeft;
			lib.saveState();
			b.setMessage(Text.literal(lib.dollLeft ? "◧" : "◨"));
			setStatus(lib.dollLeft ? "Кукла в меню будет слева" : "Кукла в меню будет справа");
		}).dimensions(4, ty, 20, 18).tooltip(Tooltip.of(Text.literal("Кукла в главном меню: слева или справа"))).build());

		// правая панель
		int x1 = panelX, x2 = panelX + 56, bw = 52, row = gy;
		nameField = new TextFieldWidget(textRenderer, x1, row, panelW, 16, Text.literal("Имя"));
		nameField.setMaxLength(32);
		nameField.setText(editName);
		addDrawableChild(nameField);
		row += 20;
		addDrawableChild(btn("<", x1, row, 20, 20, b -> switchItem(-1)));
		addDrawableChild(btn(capeMode ? "Плащ" : "Скин", x1 + 22, row, panelW - 44, 20, b -> toggleMode()))
				.setTooltip(Tooltip.of(Text.literal("Переключить: редактор скина или плаща")));
		addDrawableChild(btn(">", x1 + panelW - 20, row, 20, 20, b -> switchItem(1)));
		row += 22;
		addDrawableChild(btn("Новый", x1, row, bw, 20, b -> createNew()));
		addDrawableChild(btn("Копия", x2, row, bw, 20, b -> createCopy()));
		row += 22;
		addDrawableChild(btn("Удалить", x1, row, bw, 20, b -> askDelete()));
		if (!capeMode) {
			addDrawableChild(btn(slim ? "Руки: тонк." : "Руки: обыч.", x2, row, bw, 20, this::toggleSlim))
					.setTooltip(Tooltip.of(Text.literal("Обычные руки (4 px) или тонкие, как у Алекс (3 px)")));
		} else {
			addDrawableChild(btn("Снять", x2, row, bw, 20, b -> {
				lib.setActiveCape("");
				setStatus("Плащ снят");
			})).setTooltip(Tooltip.of(Text.literal("Ходить без плаща")));
		}
		row += 22;
		if (!capeMode) {
			ValueSlider hs = new ValueSlider(x1, row, panelW, 20, HeightHolder.MIN, HeightHolder.MAX, 0.1f, height,
					v -> Text.literal(String.format(Locale.ROOT, "Рост: %.1f бл.", v)), v -> height = v);
			hs.setTooltip(Tooltip.of(Text.literal("В мире рост меняется у шкафа-зеркала")));
			addDrawableChild(hs);
		}
		row += 22;
		addDrawableChild(btn(outer ? "Слой: вкл" : "Слой: выкл", x1, row, bw, 20, b -> {
			outer = !outer;
			b.setMessage(Text.literal(outer ? "Слой: вкл" : "Слой: выкл"));
		})).setTooltip(Tooltip.of(Text.literal("Показывать внешний слой на 3D модели")));
		addDrawableChild(btn("Наклейки", x2, row, bw, 20, b -> client.setScreen(new StickerScreen(this, s -> {
			sticker = s;
			setStatus("Кликни по развёртке. ПКМ или Esc — отмена");
		}))));
		row += 22;
		addDrawableChild(btn("Перекраска", x1, row, bw, 20, b -> openRecolor()));
		addDrawableChild(btn("Фото", x2, row, bw, 20, b -> openPhoto()));
		row += 22;
		addDrawableChild(btn("Сохранить и надеть", x1, row, panelW, 20, b -> saveAndWear()));
		row += 22;
		addDrawableChild(btn("Готово", x1, row, panelW, 20, b -> close()));

		// цвет
		int hx = gx + 8 * 12 + 24;
		hexField = new TextFieldWidget(textRenderer, hx, palY, 60, 14, Text.literal("Цвет"));
		hexField.setMaxLength(7);
		ignoreHex = true;
		hexField.setText(ColorUtil.hex(color));
		ignoreHex = false;
		hexField.setChangedListener(s -> {
			if (ignoreHex) return;
			Integer c = ColorUtil.parseHex(s);
			if (c != null) color = c;
		});
		addDrawableChild(hexField);
		addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> setColor(ColorUtil.shade(color, -0.1f)))
				.dimensions(hx + 62, palY, 14, 14).tooltip(Tooltip.of(Text.literal("Темнее"))).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> setColor(ColorUtil.shade(color, 0.1f)))
				.dimensions(hx + 78, palY, 14, 14).tooltip(Tooltip.of(Text.literal("Светлее"))).build());
	}

	private void setColor(int c) {
		color = c | 0xFF000000;
		if (hexField != null) {
			ignoreHex = true;
			hexField.setText(ColorUtil.hex(color));
			ignoreHex = false;
		}
	}

	// ---------------------------------------------------------------- кнопки

	private List<String> names() {
		List<String> out = new ArrayList<>();
		if (capeMode) out.addAll(lib.capes);
		else for (SkinLibrary.SkinEntry e : lib.skins) out.add(e.name);
		return out;
	}

	private void switchItem(int dir) {
		saveCurrent();
		List<String> n = names();
		if (n.isEmpty()) return;
		int i = Math.max(0, n.indexOf(editName));
		load(n.get(Math.floorMod(i + dir, n.size())));
		clearAndInit();
	}

	private void toggleMode() {
		saveCurrent();
		capeMode = !capeMode;
		load(null);
		clearAndInit();
	}

	private void createNew() {
		saveCurrent();
		if (capeMode) {
			load(lib.createCape("Новый плащ", SkinLayout.defaultCape()));
		} else {
			load(lib.createSkin("Новый скин", SkinLayout.defaultSkin(false), false, HeightHolder.DEFAULT).name);
		}
		clearAndInit();
		setStatus("Создано: " + editName);
	}

	private void createCopy() {
		saveCurrent();
		if (capeMode) {
			load(lib.createCape(editName + " копия", img.copy()));
		} else {
			load(lib.createSkin(editName + " копия", img.copy(), slim, height).name);
		}
		clearAndInit();
		setStatus("Копия: " + editName);
	}

	private void askDelete() {
		String target = editName;
		client.setScreen(new ConfirmScreen(ok -> {
			if (ok) {
				if (capeMode) lib.deleteCape(target);
				else lib.deleteSkin(target);
				nameField = null;
				load(null);
				setStatus("Удалено: " + target);
			}
			client.setScreen(this);
		}, Text.literal("Удалить «" + target + "»?"), Text.literal("Файл переедет в SkinStudio/backups/deleted")));
	}

	private void toggleSlim(ButtonWidget b) {
		pushUndo();
		SkinLayout.convertArms(img, !slim);
		slim = !slim;
		markChanged();
		b.setMessage(Text.literal(slim ? "Руки: тонк." : "Руки: обыч."));
	}

	private void openRecolor() {
		client.setScreen(new RecolorScreen(this, img.copy(), capeMode, slim, result -> {
			pushUndo();
			img.copyFrom(result);
			markChanged();
			setStatus("Перекраска применена");
		}, result -> {
			saveCurrent();
			if (capeMode) load(lib.createCape(editName + " вариант", result));
			else load(lib.createSkin(editName + " вариант", result, slim, height).name);
			nameField = null;
			setStatus("Сохранено как: " + editName);
		}));
	}

	private void openPhoto() {
		saveCurrent();
		if (canvasDirty) {
			canvas.update(img);
			canvasDirty = false;
		}
		Identifier skin = capeMode ? lib.activeSkinTexture() : canvas.id;
		boolean thin = capeMode ? lib.activeEntry().slim : slim;
		Identifier cape = capeMode ? canvas.id : lib.activeCapeTexture();
		client.setScreen(new PhotoScreen(this, skin, thin, cape, capeMode ? HeightHolder.DEFAULT : height));
	}

	private void saveAndWear() {
		saveCurrent();
		if (capeMode) lib.setActiveCape(editName);
		else lib.setActive(editName);
		boolean inWorld = client.world != null;
		setStatus(inWorld && !capeMode ? "Надето! Рост меняется у шкафа-зеркала" : "Сохранено и надето");
	}

	@Override
	public void close() {
		saveCurrent();
		client.setScreen(parent);
	}

	// ---------------------------------------------------------------- рисование

	private int texX(double mx) {
		return (int) Math.floor((mx - gx) / cell);
	}

	private int texY(double my) {
		return (int) Math.floor((my - gy) / cell);
	}

	private boolean inGrid(double mx, double my) {
		return mx >= gx && my >= gy && mx < gx + 64 * cell && my < gy + img.h * cell;
	}

	private boolean inPreview(double mx, double my) {
		return mx >= px0 && my >= py0 && mx < px0 + pw && my < py0 + ph;
	}

	private void paint(int x, int y, int c) {
		if (!img.inside(x, y)) return;
		img.set(x, y, c);
		if (mirror) {
			int[] m = SkinLayout.mirror(boxes(), pairs(), x, y);
			if (m != null) img.set(m[0], m[1], c);
		}
	}

	private void flood(int x, int y, int c) {
		int[] r = SkinLayout.faceRect(boxes(), x, y);
		if (r == null) return;
		int target = img.get(x, y);
		if (target == c) return;
		Deque<int[]> stack = new ArrayDeque<>();
		stack.push(new int[]{x, y});
		while (!stack.isEmpty()) {
			int[] q = stack.pop();
			int a = q[0], b = q[1];
			if (a < r[0] || b < r[1] || a >= r[0] + r[2] || b >= r[1] + r[3]) continue;
			if (img.get(a, b) != target) continue;
			img.set(a, b, c);
			stack.push(new int[]{a + 1, b});
			stack.push(new int[]{a - 1, b});
			stack.push(new int[]{a, b + 1});
			stack.push(new int[]{a, b - 1});
		}
	}

	private void pick(int x, int y) {
		int c = img.get(x, y);
		if ((c >>> 24) == 0) return;
		setColor(c);
	}

	private void applyTool(int x, int y) {
		if (!img.inside(x, y)) return;
		switch (tool) {
			case PEN -> paint(x, y, color);
			case ERASER -> paint(x, y, 0);
			case FILL -> {
				flood(x, y, color);
				if (mirror) {
					int[] m = SkinLayout.mirror(boxes(), pairs(), x, y);
					if (m != null) flood(m[0], m[1], color);
				}
			}
			case PICK -> {
				pick(x, y);
				tool = Tool.PEN;
				return;
			}
			default -> {
				return;
			}
		}
		markChanged();
	}

	private void line(int x0, int y0, int x1, int y1) {
		int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
		int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
		int err = dx + dy;
		for (int guard = 0; guard < 256; guard++) {
			applyTool(x0, y0);
			if (x0 == x1 && y0 == y1) break;
			int e2 = 2 * err;
			if (e2 >= dy) {
				err += dy;
				x0 += sx;
			}
			if (e2 <= dx) {
				err += dx;
				y0 += sy;
			}
		}
	}

	private void stamp(int x, int y) {
		if (sticker == null) return;
		PixelImage s = sticker.img();
		for (int sy = 0; sy < s.h; sy++)
			for (int sx = 0; sx < s.w; sx++) {
				int c = s.get(sx, sy);
				if ((c >>> 24) != 0) paint(x + sx, y + sy, c);
			}
		markChanged();
	}

	private void saveCut(int x0, int y0, int x1, int y1) {
		int ax = Math.max(0, Math.min(x0, x1)), ay = Math.max(0, Math.min(y0, y1));
		int bx = Math.min(img.w - 1, Math.max(x0, x1)), by = Math.min(img.h - 1, Math.max(y0, y1));
		int w = bx - ax + 1, h = by - ay + 1;
		if (w < 1 || h < 1) return;
		PixelImage piece = new PixelImage(w, h);
		boolean any = false;
		for (int y = 0; y < h; y++)
			for (int x = 0; x < w; x++) {
				int c = img.get(ax + x, ay + y);
				piece.set(x, y, c);
				if ((c >>> 24) != 0) any = true;
			}
		if (!any) {
			setStatus("Там пусто — нечего сохранять");
			return;
		}
		try {
			String base = "Наклейка";
			int n = 1;
			java.nio.file.Path p;
			do {
				p = lib.stickersDir.resolve(base + " " + n + ".png");
				n++;
			} while (java.nio.file.Files.exists(p));
			piece.write(p);
			setStatus("Наклейка сохранена: " + p.getFileName());
		} catch (Exception e) {
			setStatus("Не удалось сохранить наклейку");
		}
	}

	private boolean paletteClick(double mx, double my) {
		for (int i = 0; i < PALETTE.length; i++) {
			int sx = gx + (i % 8) * 12, sy = palY + (i / 8) * 12;
			if (mx >= sx && my >= sy && mx < sx + 10 && my < sy + 10) {
				setColor(PALETTE[i]);
				if (tool == Tool.ERASER || tool == Tool.PICK) tool = Tool.PEN;
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (super.mouseClicked(mx, my, button)) return true;
		if (paletteClick(mx, my)) return true;
		if (inGrid(mx, my)) {
			this.setFocused(null);
			int x = texX(mx), y = texY(my);
			if (sticker != null) {
				if (button == 1) {
					sticker = null;
					setStatus("Наклейка отменена");
				} else {
					pushUndo();
					stamp(x, y);
				}
				return true;
			}
			if (button == 1) {
				pick(x, y);
				return true;
			}
			if (button == 0) {
				if (tool == Tool.CUT) {
					cutting = true;
					cutX = x;
					cutY = y;
					lastX = x;
					lastY = y;
					return true;
				}
				pushUndo();
				painting = true;
				lastX = x;
				lastY = y;
				applyTool(x, y);
				return true;
			}
		}
		if (inPreview(mx, my) && button == 0) {
			this.setFocused(null);
			dragModel = true;
			dragStartX = mx;
			dragStartY = my;
			dragRotY = rotY;
			dragRotX = rotX;
			return true;
		}
		return false;
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (painting) {
			if (tool == Tool.PEN || tool == Tool.ERASER) {
				int x = texX(mx), y = texY(my);
				line(lastX, lastY, x, y);
				lastX = x;
				lastY = y;
			}
			return true;
		}
		if (cutting) {
			lastX = Math.max(0, Math.min(img.w - 1, texX(mx)));
			lastY = Math.max(0, Math.min(img.h - 1, texY(my)));
			return true;
		}
		if (dragModel) {
			rotY = dragRotY + (float) (mx - dragStartX) * 1.5f;
			rotX = Math.max(-45f, Math.min(45f, dragRotX - (float) (my - dragStartY)));
			return true;
		}
		return super.mouseDragged(mx, my, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		if (cutting) {
			cutting = false;
			saveCut(cutX, cutY, lastX, lastY);
		}
		painting = false;
		dragModel = false;
		return super.mouseReleased(mx, my, button);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (keyCode == GLFW.GLFW_KEY_ESCAPE && sticker != null) {
			sticker = null;
			return true;
		}
		boolean typing = this.getFocused() instanceof TextFieldWidget;
		if (!typing && hasControlDown()) {
			if (keyCode == GLFW.GLFW_KEY_Z) {
				doUndo();
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_Y) {
				doRedo();
				return true;
			}
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	// ---------------------------------------------------------------- отрисовка

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		this.renderBackground(ctx);
		if (canvasDirty || !canvas.ready()) {
			canvas.update(img);
			canvasDirty = false;
		}
		if (!checker.ready()) checker.update(SkinLayout.checker(64, 64));
		TextRenderer tr = this.textRenderer;

		ctx.drawTextWithShadow(tr, Text.literal("Skin Studio · " + (capeMode ? "плащ " : "скин ") + editName), gx, 8, 0xFFFFD45A);

		// развёртка
		int gw = 64 * cell, gh = img.h * cell;
		ctx.fill(gx - 1, gy - 1, gx + gw + 1, gy + gh + 1, 0xFF101114);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		ctx.drawTexture(checker.id, gx, gy, gw, gh, 0f, 0f, 64, img.h, 64, 64);
		ctx.drawTexture(canvas.id, gx, gy, gw, gh, 0f, 0f, img.w, img.h, img.w, img.h);
		RenderSystem.disableBlend();

		List<SkinLayout.Box> boxes = boxes();
		boolean hoverGrid = inGrid(mx, my);
		int hx = hoverGrid ? texX(mx) : -1, hy = hoverGrid ? texY(my) : -1;
		int hoverBox = hoverGrid ? SkinLayout.boxAt(boxes, hx, hy) : -1;
		for (int i = 0; i < boxes.size(); i++) {
			int[] r = boxes.get(i).bounds();
			ctx.drawBorder(gx + r[0] * cell, gy + r[1] * cell, r[2] * cell, r[3] * cell, i == hoverBox ? 0xC0FFD45A : 0x40FFFFFF);
		}
		if (hoverBox >= 0) {
			SkinLayout.Box b = boxes.get(hoverBox);
			for (int f = 0; f < 6; f++) {
				int[] r = b.face(f);
				ctx.drawBorder(gx + r[0] * cell, gy + r[1] * cell, r[2] * cell, r[3] * cell, 0x50FFD45A);
			}
		}
		if (cutting) {
			int ax = Math.min(cutX, lastX), ay = Math.min(cutY, lastY);
			int bx = Math.max(cutX, lastX), by = Math.max(cutY, lastY);
			ctx.drawBorder(gx + ax * cell, gy + ay * cell, (bx - ax + 1) * cell, (by - ay + 1) * cell, 0xFF6FB03F);
		} else if (hoverGrid) {
			if (sticker != null) {
				PixelImage s = sticker.img();
				for (int sy = 0; sy < s.h; sy++)
					for (int sx = 0; sx < s.w; sx++) {
						int c = s.get(sx, sy);
						int tx = hx + sx, tyy = hy + sy;
						if ((c >>> 24) == 0 || !img.inside(tx, tyy)) continue;
						ctx.fill(gx + tx * cell, gy + tyy * cell, gx + (tx + 1) * cell, gy + (tyy + 1) * cell, (c & 0xFFFFFF) | 0xB0000000);
					}
			} else {
				ctx.drawBorder(gx + hx * cell, gy + hy * cell, cell, cell, 0xFFFFD45A);
				if (mirror) {
					int[] m = SkinLayout.mirror(boxes, pairs(), hx, hy);
					if (m != null) ctx.drawBorder(gx + m[0] * cell, gy + m[1] * cell, cell, cell, 0x90FFD45A);
				}
			}
		}

		// 3D модель
		ctx.fill(px0, py0, px0 + pw, py0 + ph, 0xFF2A3340);
		ctx.enableScissor(px0, py0, px0 + pw, py0 + ph);
		Identifier skinId = capeMode ? lib.activeSkinTexture() : canvas.id;
		boolean thin = capeMode ? lib.activeEntry().slim : slim;
		Identifier capeId = capeMode ? canvas.id : lib.activeCapeTexture();
		float scale = capeMode ? HeightHolder.DEFAULT : height;
		int pxH = (int) ((ph - 26) * scale / HeightHolder.MAX);
		float t = (Util.getMeasuringTimeMs() % 3600000L) / 50f;
		ModelRenderer.draw(ctx, px0 + pw / 2, py0 + ph - 12, pxH, rotY + (capeMode ? 180f : 0f), rotX, 0f, 0f,
				skinId, thin, capeId, outer, ModelRenderer.Pose.STAND, t);
		ctx.disableScissor();
		ctx.drawCenteredTextWithShadow(tr, Text.literal("тяни мышкой"), px0 + pw / 2, py0 + 3, 0xFF9AA0A6);
		if (!capeMode) ctx.drawTextWithShadow(tr, String.format(Locale.ROOT, "%.1f бл.", height), px0 + 3, py0 + ph - 10, 0xFFCFD8DC);

		// палитра
		for (int i = 0; i < PALETTE.length; i++) {
			int sx = gx + (i % 8) * 12, sy = palY + (i / 8) * 12;
			ctx.fill(sx - 1, sy - 1, sx + 11, sy + 11, PALETTE[i] == color ? 0xFFFFD45A : 0xFF3A3D44);
			ctx.fill(sx, sy, sx + 10, sy + 10, PALETTE[i]);
		}
		int cx = gx + 8 * 12 + 4;
		ctx.fill(cx - 1, palY - 1, cx + 17, palY + 23, 0xFF3A3D44);
		ctx.fill(cx, palY, cx + 16, palY + 22, color);

		// подсказка
		String info;
		if (Util.getMeasuringTimeMs() < statusUntil) info = status;
		else if (hoverBox >= 0) info = boxes.get(hoverBox).name() + " · x " + hx + ", y " + hy;
		else info = tool.title;
		ctx.drawTextWithShadow(tr, info, gx, palY + 28, 0xFFCFD8DC);

		super.render(ctx, mx, my, delta);

		// подсветка активного инструмента
		for (int i = 0; i < toolButtons.size(); i++) {
			if (Tool.values()[i] == tool && sticker == null) {
				ButtonWidget b = toolButtons.get(i);
				ctx.drawBorder(b.getX() - 1, b.getY() - 1, b.getWidth() + 2, b.getHeight() + 2, 0xFFFFD45A);
			}
		}
		if (mirror && mirrorButton != null) {
			ctx.drawBorder(mirrorButton.getX() - 1, mirrorButton.getY() - 1, mirrorButton.getWidth() + 2, mirrorButton.getHeight() + 2, 0xFFFFD45A);
		}
	}
}
