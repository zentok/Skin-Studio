package com.skinstudio.mixin.client;

import com.skinstudio.client.SkinLibrary;
import com.skinstudio.client.gui.DollWidget;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Кукла со скином справа (или слева) от кнопок главного меню. */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
	protected TitleScreenMixin(Text title) {
		super(title);
	}

	@Inject(method = "init", at = @At("TAIL"))
	private void skinstudio$addDoll(CallbackInfo ci) {
		SkinLibrary lib = SkinLibrary.get();
		int w = 74;
		int h = 128;
		int x = lib.dollLeft ? this.width / 2 - 100 - 16 - w : this.width / 2 + 100 + 16;
		x = Math.max(4, Math.min(this.width - w - 4, x));
		int y = this.height / 4 + 36;
		if (y + h > this.height - 4) y = this.height - h - 4;
		int arrowsY = y + h - 12;
		// стрелки добавляем первыми, чтобы клик по ним не открывал редактор
		this.addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> lib.cycle(-1))
				.dimensions(x, arrowsY, 14, 12).build());
		this.addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> lib.cycle(1))
				.dimensions(x + w - 14, arrowsY, 14, 12).build());
		this.addDrawableChild(new DollWidget(x, y, w, h));
	}
}
